# Android V4.2 mobile update

- Synchronized the shared game sources with NumWorks V4.2 Quality.
- Moved the virtual controls from the game canvas to physical display edge positions.
- Kept the original 320x240 game viewport centered and proportional.
- Captured the joystick pointer from touch-down until that pointer is lifted, even when dragged outside the base.
- Prevented the movement finger from accidentally triggering action buttons while dragging.
- Kept the keypad and hardware-key mappings.
- Restored larger touch-control sizing while keeping the edge-anchored positions unchanged.
- Removed the obsolete NumWorks "Keys" page from Android How to Play; the guide now has two pages.
- Hid calculator-key legend strips on Android because touch controls are displayed on screen.



Lobby touch fix: the blue button increases the selected setting and activates Start when the Start row is selected; the red button decreases settings. The joystick remains vertical navigation only. In-game action mappings are unchanged.

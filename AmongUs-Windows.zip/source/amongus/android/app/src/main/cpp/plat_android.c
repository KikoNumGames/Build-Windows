/* Android platform layer: original 320x240 game frame with edge-anchored touch controls. */
#include <android/native_activity.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/input.h>
#include <android/log.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "plat.h"
#include "game.h"
#include "mg.h"

#define LOG_TAG "AmongUsMobile"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static ANativeWindow *s_window;
static char s_data_dir[512];
static uint16_t s_frame[SCREEN_W * SCREEN_H];
static uint32_t s_keys;
static uint32_t s_hardware_keys;
static int s_view_x, s_view_y, s_view_w, s_view_h;
static float s_scale;
static struct { int down; float x, y; } s_touches[16];
static int s_joystick_id = -1;
static uint8_t s_overlay_visible = 1;

static uint32_t clock_ms(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (uint32_t)(ts.tv_sec * 1000u + ts.tv_nsec / 1000000u);
}

uint32_t plat_millis(void) { return clock_ms(); }
void plat_sleep(uint32_t ms) {
  struct timespec req = {(time_t)(ms / 1000), (long)(ms % 1000) * 1000000L};
  nanosleep(&req, NULL);
}

static void update_viewport(int w, int h) {
  s_scale = fminf((float)w / SCREEN_W, (float)h / SCREEN_H);
  if (s_scale <= 0) s_scale = 1;
  s_view_w = (int)(SCREEN_W * s_scale);
  s_view_h = (int)(SCREEN_H * s_scale);
  s_view_x = (w - s_view_w) / 2;
  s_view_y = (h - s_view_h) / 2;
}

static uint16_t mix565(uint16_t dst, uint16_t src, unsigned a) {
  unsigned dr = (dst >> 11) & 31, dg = (dst >> 5) & 63, db = dst & 31;
  unsigned sr = (src >> 11) & 31, sg = (src >> 5) & 63, sb = src & 31;
  unsigned r = (dr * (255 - a) + sr * a) / 255;
  unsigned g = (dg * (255 - a) + sg * a) / 255;
  unsigned b = (db * (255 - a) + sb * a) / 255;
  return (uint16_t)((r << 11) | (g << 5) | b);
}

/* Touch UI is drawn in physical display coordinates, outside the 4:3 game viewport. */
static void ui_disc(uint16_t *dst, int stride, int w, int h,
                    int cx, int cy, int radius, uint16_t color, unsigned alpha) {
  int r2 = radius * radius;
  int y0 = cy - radius, y1 = cy + radius;
  int x0 = cx - radius, x1 = cx + radius;
  if (y0 < 0) y0 = 0; if (y1 >= h) y1 = h - 1;
  if (x0 < 0) x0 = 0; if (x1 >= w) x1 = w - 1;
  for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
    int dx = x - cx, dy = y - cy;
    if (dx * dx + dy * dy <= r2) {
      uint16_t *q = &dst[y * stride + x];
      *q = mix565(*q, color, alpha);
    }
  }
}

static void ui_ring(uint16_t *dst, int stride, int w, int h,
                    int cx, int cy, int radius, uint16_t color, int thickness) {
  int outer = radius * radius, ir = radius - thickness, inner = ir > 0 ? ir * ir : 0;
  int y0 = cy - radius, y1 = cy + radius, x0 = cx - radius, x1 = cx + radius;
  if (y0 < 0) y0 = 0; if (y1 >= h) y1 = h - 1;
  if (x0 < 0) x0 = 0; if (x1 >= w) x1 = w - 1;
  for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
    int dx = x - cx, dy = y - cy, d = dx * dx + dy * dy;
    if (d <= outer && d >= inner) dst[y * stride + x] = color;
  }
}

static void ui_line(uint16_t *dst, int stride, int w, int h,
                    int x0, int y0, int x1, int y1, uint16_t color, int thick) {
  int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
  int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
  for (;;) {
    ui_disc(dst, stride, w, h, x0, y0, thick, color, 255);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 >= dy) err += dy, x0 += sx;
    if (e2 <= dx) err += dx, y0 += sy;
  }
}

static void ui_digit(uint16_t *dst, int stride, int w, int h,
                     int n, int cx, int cy, uint16_t color) {
  static const uint8_t seg[10] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
  static const int x0[7] = {-4,4,4,-4,-4,-4,0}, y0[7] = {-6,-6,0,6,0,-6,0};
  static const int x1[7] = {4,4,4,4,-4,-4,0}, y1[7] = {-6,0,6,6,6,0,0};
  for (int i = 0; i < 7; i++) if (seg[n] & (1u << i)) {
    if (i == 6) ui_line(dst,stride,w,h,cx-4,cy,cx+4,cy,color,1);
    else ui_line(dst,stride,w,h,cx+x0[i],cy+y0[i],cx+x1[i],cy+y1[i],color,1);
  }
}

static int keypad_active(void) { return g.overlay == O_TASK && M->kind == MG_KEYPAD; }

static void draw_mobile_controls(ANativeWindow_Buffer *b) {
  if (!s_overlay_visible) return;
  uint16_t *dst = (uint16_t *)b->bits;
  int w = b->width, h = b->height, stride = b->stride;
  const uint16_t white = 0xFFFF, dark = 0x18E3, blue = 0x4D7F, red = 0xF986;
  int short_side = w < h ? w : h;
  int r = short_side / 6;
  if (r < 44) r = 44;
  if (r > 90) r = 90;
  int jx = w * 12 / 100, jy = h * 81 / 100;
  int okx = w * 92 / 100, oky = h * 81 / 100;
  int ex = w * 92 / 100, ey = h * 59 / 100;
  int tx = w * 81 / 100, ty = h * 81 / 100;
  int px = w * 95 / 100, py = h * 10 / 100;

  ui_disc(dst,stride,w,h,jx,jy,r,dark,105);
  ui_ring(dst,stride,w,h,jx,jy,r,white,2);
  int kx = jx, ky = jy;
  if (s_joystick_id >= 0 && s_joystick_id < 16 && s_touches[s_joystick_id].down) {
    float dx = s_touches[s_joystick_id].x - jx, dy = s_touches[s_joystick_id].y - jy;
    float d = sqrtf(dx * dx + dy * dy), max = r * 0.62f;
    if (d > max && d > 0) dx *= max / d, dy *= max / d;
    kx += (int)dx; ky += (int)dy;
  }
  ui_disc(dst,stride,w,h,kx,ky,r*38/66,0xBDF7,205);
  ui_ring(dst,stride,w,h,kx,ky,r*38/66,white,2);

  ui_disc(dst,stride,w,h,okx,oky,r*0.98f,blue,150);
  ui_ring(dst,stride,w,h,okx,oky,r*0.98f,white,2);
  ui_disc(dst,stride,w,h,ex,ey,r*0.92f,red,145);
  ui_ring(dst,stride,w,h,ex,ey,r*0.92f,white,2);
  ui_disc(dst,stride,w,h,tx,ty,r*0.82f,dark,145);
  ui_ring(dst,stride,w,h,tx,ty,r*0.82f,white,2);
  ui_disc(dst,stride,w,h,px,py,r*0.68f,dark,175);
  ui_ring(dst,stride,w,h,px,py,r*0.68f,white,2);

  /* Bot-memory button: top-left, directly above the movement joystick. */
  int mx = w * 12 / 100, my = h * 10 / 100;
  if (g.screen == S_MEETING) {
    ui_disc(dst,stride,w,h,mx,my,r*0.68f,0x245B,190);
    ui_ring(dst,stride,w,h,mx,my,r*0.68f,white,2);
    ui_line(dst,stride,w,h,mx-13,my-10,mx-2,my-7,white,2);
    ui_line(dst,stride,w,h,mx-2,my-7,mx-2,my+11,white,2);
    ui_line(dst,stride,w,h,mx+2,my-7,mx+13,my-10,white,2);
    ui_line(dst,stride,w,h,mx+2,my-7,mx+2,my+11,white,2);
    ui_line(dst,stride,w,h,mx-13,my-10,mx-13,my+8,white,2);
    ui_line(dst,stride,w,h,mx+13,my-10,mx+13,my+8,white,2);
    ui_line(dst,stride,w,h,mx-13,my+8,mx-2,my+11,white,2);
    ui_line(dst,stride,w,h,mx+13,my+8,mx+2,my+11,white,2);
  }

  /* Simple, recognizable action glyphs. */
  ui_disc(dst,stride,w,h,okx,oky,7,white,255);
  ui_line(dst,stride,w,h,ex-14,ey-14,ex+14,ey+14,white,4);
  ui_line(dst,stride,w,h,ex+14,ey-14,ex-14,ey+14,white,4);
  ui_line(dst,stride,w,h,tx-14,ty-5,tx+14,ty-5,white,3);
  ui_line(dst,stride,w,h,tx-14,ty+5,tx+14,ty+5,white,3);
  ui_line(dst,stride,w,h,px-7,py-10,px-7,py+10,white,3);
  ui_line(dst,stride,w,h,px+7,py-10,px+7,py+10,white,3);

  /* Dedicated quick-chat button: visible only during meetings.
     It sits directly above the red action button, without moving existing controls. */
  if (g.screen == S_MEETING) {
    int qx = w * 92 / 100, qy = h * 34 / 100;
    ui_disc(dst,stride,w,h,qx,qy,r*0.58f,0x245B,190);
    ui_ring(dst,stride,w,h,qx,qy,r*0.58f,white,2);
    ui_line(dst,stride,w,h,qx-13,qy-9,qx+13,qy-9,white,2);
    ui_line(dst,stride,w,h,qx-13,qy-9,qx-13,qy+7,white,2);
    ui_line(dst,stride,w,h,qx+13,qy-9,qx+13,qy+7,white,2);
    ui_line(dst,stride,w,h,qx-13,qy+7,qx-4,qy+7,white,2);
    ui_line(dst,stride,w,h,qx-4,qy+7,qx-10,qy+13,white,2);
    ui_line(dst,stride,w,h,qx-10,qy+13,qx-10,qy+7,white,2);
    ui_line(dst,stride,w,h,qx-6,qy-2,qx-6,qy-2,white,3);
    ui_line(dst,stride,w,h,qx,qy-2,qx,qy-2,white,3);
    ui_line(dst,stride,w,h,qx+6,qy-2,qx+6,qy-2,white,3);
  }

  if (keypad_active()) {
    int size = r * 0.43f, gap = r * 0.12f;
    int startx = w * 70 / 100 - (size * 3 + gap * 2) / 2;
    int starty = h / 2 - (size * 4 + gap * 3) / 2;
    for (int d = 1; d <= 9; d++) {
      int cx = startx + ((d - 1) % 3) * (size + gap) + size / 2;
      int cy = starty + ((d - 1) / 3) * (size + gap) + size / 2;
      ui_disc(dst,stride,w,h,cx,cy,size/2,dark,205);
      ui_ring(dst,stride,w,h,cx,cy,size/2,white,2);
      ui_digit(dst,stride,w,h,d,cx,cy,white);
    }
    int cx = startx + size / 2, cy = starty + 3 * (size + gap) + size / 2;
    ui_disc(dst,stride,w,h,cx,cy,size/2,dark,205);
    ui_ring(dst,stride,w,h,cx,cy,size/2,white,2);
    ui_digit(dst,stride,w,h,0,cx,cy,white);
  }
}

static void present_frame(void) {
  if (!s_window) return;
  ANativeWindow_Buffer buffer;
  if (ANativeWindow_lock(s_window, &buffer, NULL) != 0) return;
  if (buffer.format != WINDOW_FORMAT_RGB_565) {
    ANativeWindow_unlockAndPost(s_window);
    return;
  }
  update_viewport(buffer.width, buffer.height);
  uint16_t *dst = (uint16_t *)buffer.bits;
  for (int y = 0; y < buffer.height; y++) {
    uint16_t *row = dst + y * buffer.stride;
    for (int x = 0; x < buffer.width; x++) row[x] = 0x0000;
  }
  for (int y = 0; y < s_view_h; y++) {
    int sy = (int)((float)y / s_scale);
    if (sy >= SCREEN_H) sy = SCREEN_H - 1;
    uint16_t *row = dst + (s_view_y + y) * buffer.stride + s_view_x;
    for (int x = 0; x < s_view_w; x++) {
      int sx = (int)((float)x / s_scale);
      if (sx >= SCREEN_W) sx = SCREEN_W - 1;
      row[x] = s_frame[sy * SCREEN_W + sx];
    }
  }
  draw_mobile_controls(&buffer);
  ANativeWindow_unlockAndPost(s_window);
}

void plat_push(int x, int y, int w, int h, const uint16_t *px) {
  if (!px || x < 0 || y < 0 || x + w > SCREEN_W || y + h > SCREEN_H) return;
  for (int r = 0; r < h; r++) memcpy(&s_frame[(y + r) * SCREEN_W + x], &px[r * w], (size_t)w * sizeof(uint16_t));
  if (y + h >= SCREEN_H) present_frame();
}

static void touch_to_canvas(float sx, float sy, float *x, float *y) {
  if (!s_window || s_scale <= 0) { *x = sx; *y = sy; return; }
  *x = (sx - s_view_x) / s_scale;
  *y = (sy - s_view_y) / s_scale;
}

static uint32_t keys_for_touch(float x, float y) {
  uint32_t k = 0;
  int w = s_window ? ANativeWindow_getWidth(s_window) : SCREEN_W;
  int h = s_window ? ANativeWindow_getHeight(s_window) : SCREEN_H;
  int short_side = w < h ? w : h;
  int r = short_side / 6;
  if (r < 44) r = 44;
  if (r > 90) r = 90;
  int okx = w * 92 / 100, oky = h * 81 / 100;
  int ex = w * 92 / 100, ey = h * 59 / 100;
  int tx = w * 81 / 100, ty = h * 81 / 100;
  int px = w * 95 / 100, py = h * 10 / 100;
  int mx = w * 12 / 100, my = h * 10 / 100;
  int qx = w * 92 / 100, qy = h * 34 / 100;
  if (g.screen == S_MEETING &&
      x > mx-r*0.78f && x < mx+r*0.78f &&
      y > my-r*0.78f && y < my+r*0.78f) return K_VAR;
  if (g.screen == S_MEETING &&
      x > qx-r*0.66f && x < qx+r*0.66f &&
      y > qy-r*0.66f && y < qy+r*0.66f) return K_CHAT;

  if (keypad_active()) {
    int size = r * 0.43f, gap = r * 0.12f;
    int startx = w * 70 / 100 - (size * 3 + gap * 2) / 2;
    int starty = h / 2 - (size * 4 + gap * 3) / 2;
    if (x >= startx && x <= startx + size * 3 + gap * 2 &&
        y >= starty && y <= starty + size * 4 + gap * 3) {
      int col = (int)(x - startx) / (size + gap);
      int row = (int)(y - starty) / (size + gap);
      if (col >= 0 && col < 3 && row >= 0 && row < 3) {
        int digit = row * 3 + col + 1;
        return (uint32_t)K_D0 << digit;
      }
      if (row == 3 && col == 0) return K_D0;
    }
  }

  /* In the pre-game settings, the blue and red action buttons change the
     selected option directly. During gameplay they keep their normal actions. */
  if (x > okx-r*1.04f && x < okx+r*1.04f &&
      y > oky-r*1.04f && y < oky+r*1.04f)
    k |= (g.screen == S_LOBBY
              ? (lobby_start_selected() ? K_OK : K_RIGHT)
              : K_OK);
  if (x > ex-r*0.98f && x < ex+r*0.98f &&
      y > ey-r*0.98f && y < ey+r*0.98f) {
    if (g.screen == S_MEETING && meeting_memory_is_open()) k |= K_BACK;
    else if (g.screen == S_MEETING && g.chat_open) k |= K_BACK;
    else k |= (g.screen == S_LOBBY ? K_LEFT : K_EXE);
  }
  if (x > tx-r*0.88f && x < tx+r*0.88f &&
      y > ty-r*0.88f && y < ty+r*0.88f) k |= K_TOOL;
  if (x > px-r*0.74f && x < px+r*0.74f &&
      y > py-r*0.74f && y < py+r*0.74f)
    k |= (g.screen == S_MEETING ? K_PLUS : K_BACK);

  return k;
}

static void refresh_touch_keys(void) {
  uint32_t k = 0;
  for (int i = 0; i < 16; i++) {
    if (!s_touches[i].down) continue;
    /* Do not let a dragged movement finger accidentally activate action buttons. */
    if (i != s_joystick_id) k |= keys_for_touch(s_touches[i].x, s_touches[i].y);
  }
  /* Keep the movement pointer captured until that exact finger is lifted, even outside the joystick ring. */
  if (s_joystick_id >= 0 && s_joystick_id < 16 && s_touches[s_joystick_id].down) {
    int w = s_window ? ANativeWindow_getWidth(s_window) : SCREEN_W;
    int h = s_window ? ANativeWindow_getHeight(s_window) : SCREEN_H;
    int short_side = w < h ? w : h;
    int r = short_side / 6;
    if (r < 44) r = 44;
    if (r > 90) r = 90;
    float dx = s_touches[s_joystick_id].x - w * 0.12f;
    float dy = s_touches[s_joystick_id].y - h * 0.81f;
    float dead = r * 0.16f;
    /* In the lobby the joystick only navigates the list vertically.
       Option values are changed with the dedicated blue/red buttons. */
    if (g.screen != S_LOBBY) {
      if (dx < -dead) k |= K_LEFT;
      if (dx > dead) k |= K_RIGHT;
    }
    if (dy < -dead) k |= K_UP;
    if (dy > dead) k |= K_DOWN;
  }
  s_keys = s_hardware_keys | k;
}

int32_t android_handle_input(struct android_app *app, AInputEvent *event) {
  (void)app;
  int type = AInputEvent_getType(event);
  if (type == AINPUT_EVENT_TYPE_KEY) {
    int action = AKeyEvent_getAction(event), code = AKeyEvent_getKeyCode(event);
    uint32_t bit = 0;
    switch (code) {
      case AKEYCODE_DPAD_LEFT: bit = K_LEFT; break;
      case AKEYCODE_DPAD_RIGHT: bit = K_RIGHT; break;
      case AKEYCODE_DPAD_UP: bit = K_UP; break;
      case AKEYCODE_DPAD_DOWN: bit = K_DOWN; break;
      case AKEYCODE_DPAD_CENTER: case AKEYCODE_ENTER: bit = K_OK; break;
      case AKEYCODE_BACK: bit = K_BACK; break;
      case AKEYCODE_SPACE: bit = K_EXE; break;
      case AKEYCODE_M: bit = K_TOOL; break;
      case AKEYCODE_PLUS: case AKEYCODE_NUMPAD_ADD: bit = K_PLUS; break;
      case AKEYCODE_0: bit = K_D0; break;
      case AKEYCODE_1: bit = (uint32_t)K_D0 << 1; break;
      case AKEYCODE_2: bit = (uint32_t)K_D0 << 2; break;
      case AKEYCODE_3: bit = (uint32_t)K_D0 << 3; break;
      case AKEYCODE_4: bit = (uint32_t)K_D0 << 4; break;
      case AKEYCODE_5: bit = (uint32_t)K_D0 << 5; break;
      case AKEYCODE_6: bit = (uint32_t)K_D0 << 6; break;
      case AKEYCODE_7: bit = (uint32_t)K_D0 << 7; break;
      case AKEYCODE_8: bit = (uint32_t)K_D0 << 8; break;
      case AKEYCODE_9: bit = (uint32_t)K_D0 << 9; break;
      default: break;
    }
    if (action == AKEY_EVENT_ACTION_DOWN) s_hardware_keys |= bit;
    else if (action == AKEY_EVENT_ACTION_UP) s_hardware_keys &= ~bit;
    refresh_touch_keys();
    return 1;
  }
  if (type == AINPUT_EVENT_TYPE_MOTION) {
    int action = AMotionEvent_getAction(event), masked = action & AMOTION_EVENT_ACTION_MASK;
    int index = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    int count = AMotionEvent_getPointerCount(event);
    if (masked == AMOTION_EVENT_ACTION_CANCEL) {
      memset(s_touches, 0, sizeof s_touches);
      s_joystick_id = -1;
      refresh_touch_keys();
      return 1;
    }
    if (masked == AMOTION_EVENT_ACTION_DOWN || masked == AMOTION_EVENT_ACTION_POINTER_DOWN ||
        masked == AMOTION_EVENT_ACTION_MOVE || masked == AMOTION_EVENT_ACTION_UP || masked == AMOTION_EVENT_ACTION_POINTER_UP) {
      for (int p = 0; p < count; p++) {
        int id = AMotionEvent_getPointerId(event, p);
        if (id < 0 || id >= 16) continue;
        float x = AMotionEvent_getX(event, p), y = AMotionEvent_getY(event, p);
        if ((masked == AMOTION_EVENT_ACTION_UP || masked == AMOTION_EVENT_ACTION_POINTER_UP) && p == index) {
          s_touches[id].down = 0;
          if (s_joystick_id == id) s_joystick_id = -1;
          continue;
        }
        s_touches[id].down = 1;
        s_touches[id].x = x;
        s_touches[id].y = y;
        if ((masked == AMOTION_EVENT_ACTION_DOWN || masked == AMOTION_EVENT_ACTION_POINTER_DOWN) &&
            s_joystick_id < 0) {
          int w = s_window ? ANativeWindow_getWidth(s_window) : SCREEN_W;
          int h = s_window ? ANativeWindow_getHeight(s_window) : SCREEN_H;
          int short_side = w < h ? w : h;
          int r = short_side / 6;
          if (r < 44) r = 44;
          if (r > 90) r = 90;
          float cx = w * 0.12f, cy = h * 0.81f;
          float dx = x - cx, dy = y - cy;
          if (dx * dx + dy * dy <= (r * 1.35f) * (r * 1.35f)) s_joystick_id = id;
        }
      }
      refresh_touch_keys();
      return 1;
    }
  }
  return 0;
}

void plat_set_window(ANativeWindow *window) {
  s_window = window;
  if (s_window) ANativeWindow_setBuffersGeometry(s_window, 0, 0, WINDOW_FORMAT_RGB_565);
}
void plat_set_data_dir(const char *path) { snprintf(s_data_dir, sizeof s_data_dir, "%s", path ? path : "."); }
void plat_set_keys(uint32_t keys) { s_hardware_keys = keys; refresh_touch_keys(); }
void plat_clear_input(void) { s_hardware_keys = 0; memset(s_touches, 0, sizeof s_touches); s_keys = 0; }
uint32_t plat_keys(void) { return s_keys; }
void plat_begin(void) { memset(s_frame, 0, sizeof s_frame); }
int plat_end(void) { return 0; }

static void make_path(char *out, size_t cap, const char *name) {
  snprintf(out, cap, "%s/%s", s_data_dir[0] ? s_data_dir : ".", name);
}
bool plat_save(const char *name, const void *data, uint32_t len) {
  char path[768]; make_path(path, sizeof path, name);
  FILE *f = fopen(path, "wb"); if (!f) return false;
  bool ok = fwrite(data, 1, len, f) == len;
  if (fclose(f) != 0) ok = false;
  return ok;
}
const uint8_t *plat_load(const char *name, uint32_t *len) {
  static uint8_t buffers[4][1 << 16]; static unsigned slot;
  char path[768]; make_path(path, sizeof path, name);
  FILE *f = fopen(path, "rb"); if (!f) return NULL;
  uint8_t *b = buffers[slot++ & 3]; size_t n = fread(b, 1, sizeof buffers[0], f);
  int extra = fgetc(f); fclose(f);
  if (extra != EOF) return NULL;
  if (len) *len = (uint32_t)n;
  return b;
}
bool plat_remove(const char *name) { char path[768]; make_path(path, sizeof path, name); return remove(path) == 0; }

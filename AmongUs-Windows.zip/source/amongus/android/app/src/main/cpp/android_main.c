/* NativeActivity entry point. It deliberately reuses the original game loop and simulation tick rate. */
#include <android/log.h>
#include <android/native_activity.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <stdint.h>
#include "game.h"
#include "gfx.h"
#include "plat.h"

#define LOG_TAG "AmongUsMobile"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern int32_t android_handle_input(struct android_app *app, AInputEvent *event);
extern void plat_set_window(ANativeWindow *window);
extern void plat_set_data_dir(const char *path);
extern void plat_clear_input(void);
extern bool game_running;

static int s_started;
static int s_active;

/* Use the NativeActivity API directly instead of calling Java UI methods through
 * JNI during lifecycle callbacks. This avoids fragile JNI lookups at startup. */
static void configure_activity(struct android_app *app) {
  ANativeActivity_setWindowFlags(
      app->activity,
      0x00000400,
      0);
}

static void handle_cmd(struct android_app *app, int32_t cmd) {
  switch (cmd) {
    case APP_CMD_INIT_WINDOW:
      plat_set_window(app->window);
      configure_activity(app);
      s_active = 1;
      LOGI("Native window initialized");
      break;
    case APP_CMD_TERM_WINDOW:
      s_active = 0;
      plat_set_window(NULL);
      plat_clear_input();
      LOGI("Native window released");
      break;
    case APP_CMD_GAINED_FOCUS:
      s_active = 1;
      configure_activity(app);
      LOGI("Application gained focus");
      break;
    case APP_CMD_LOST_FOCUS:
      s_active = 0;
      plat_clear_input();
      LOGI("Application lost focus");
      if (s_started && round_live()) game_save();
      break;
    case APP_CMD_PAUSE:
      if (s_started && round_live()) game_save();
      break;
    case APP_CMD_SAVE_STATE:
      if (s_started) game_save();
      break;
    default:
      break;
  }
}

void android_main(struct android_app *app) {
  app_dummy();
  LOGI("android_main entered");
  app->onAppCmd = handle_cmd;
  app->onInputEvent = android_handle_input;
  plat_set_data_dir(app->activity->internalDataPath);

  uint16_t band[SCREEN_W * BAND];
  gfx_init(band);
  plat_begin();

  uint32_t next = 0;
  while (app->destroyRequested == 0 && game_running) {
    int events;
    struct android_poll_source *source;
    while (ALooper_pollOnce(app->window ? 0 : 100, NULL, &events, (void **)&source) >= 0) {
      if (source) source->process(app, source);
      if (app->destroyRequested) break;
    }
    if (app->destroyRequested) break;
    if (!app->window || !s_active) { if (app->window) plat_sleep(20); continue; }
    if (!s_started) {
      LOGI("Initializing game");
      game_init();
      s_started = 1;
      LOGI("Game initialized");
      next = plat_millis() * 3;
      LOGI("Game initialized on Android");
    }

    int ticks = 0;
    uint32_t now = plat_millis() * 3;
    while ((int32_t)(now - next) >= 0 && ticks < 3 && game_running) {
      game_tick(plat_keys());
      next += 100; /* fixed 30 Hz simulation, same as NumWorks */
      ticks++;
    }
    if (!game_running) break;
    if ((int32_t)(now - next) > 300) next = now;
    if (ticks) game_draw();
    else plat_sleep(2);
  }
  if (s_started && round_live()) game_save();
  plat_end();
}

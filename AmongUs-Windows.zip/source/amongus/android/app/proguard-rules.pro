# NativeActivity application: all game code is compiled by the Android NDK.

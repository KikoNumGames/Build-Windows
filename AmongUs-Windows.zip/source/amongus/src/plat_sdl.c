/* Browser/desktop platform using SDL2. The same renderer is compiled to WebAssembly. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <SDL.h>
#include "plat.h"

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#include <emscripten/html5.h>
#endif

static SDL_Window *window;
static SDL_Renderer *renderer;
static SDL_Texture *texture;
static uint16_t framebuffer[SCREEN_W * SCREEN_H];
static uint32_t held;

static void map_key(const Uint8 *k, uint32_t *v, SDL_Scancode a, SDL_Scancode b) {
  if (k[a] || (b != SDL_SCANCODE_UNKNOWN && k[b])) *v |= 1;
}
uint32_t plat_keys(void) {
  SDL_Event e;
  bool quit_requested = false;
  while (SDL_PollEvent(&e)) {
    if (e.type == SDL_QUIT) quit_requested = true;
  }
  const Uint8 *k = SDL_GetKeyboardState(NULL);
  uint32_t v = quit_requested ? K_HOME : 0;
  /* W/A are the physical positions of Z/Q on an AZERTY keyboard.
     Also accept Z/Q directly for layouts where SDL reports those scancodes. */
  if (k[SDL_SCANCODE_UP] || k[SDL_SCANCODE_W] || k[SDL_SCANCODE_Z]) v |= K_UP;
  if (k[SDL_SCANCODE_DOWN] || k[SDL_SCANCODE_S]) v |= K_DOWN;
  if (k[SDL_SCANCODE_LEFT] || k[SDL_SCANCODE_A] || k[SDL_SCANCODE_Q]) v |= K_LEFT;
  if (k[SDL_SCANCODE_RIGHT] || k[SDL_SCANCODE_D]) v |= K_RIGHT;
  if (k[SDL_SCANCODE_E] || k[SDL_SCANCODE_RETURN]) v |= K_OK;
  if (k[SDL_SCANCODE_SPACE]) v |= K_EXE;
  if (k[SDL_SCANCODE_TAB]) v |= K_TOOL;
  if (k[SDL_SCANCODE_ESCAPE] || k[SDL_SCANCODE_BACKSPACE]) v |= K_BACK;
  if (k[SDL_SCANCODE_HOME]) v |= K_HOME;
  if (k[SDL_SCANCODE_RETURN]) v |= K_CHAT;
  if (k[SDL_SCANCODE_F1]) v |= K_VAR;
  if (k[SDL_SCANCODE_P]) v |= K_PLUS;
  static const SDL_Scancode digit_scancodes[10] = {
    SDL_SCANCODE_0, SDL_SCANCODE_1, SDL_SCANCODE_2, SDL_SCANCODE_3, SDL_SCANCODE_4,
    SDL_SCANCODE_5, SDL_SCANCODE_6, SDL_SCANCODE_7, SDL_SCANCODE_8, SDL_SCANCODE_9
  };
  for (int i = 0; i < 10; i++) if (k[digit_scancodes[i]]) v |= K_D0 << i;
  held = v;
  return held;
}
uint32_t plat_millis(void) { return SDL_GetTicks(); }
void plat_sleep(uint32_t ms) { SDL_Delay(ms); }

void plat_push(int x, int y, int w, int h, const uint16_t *px) {
  for (int r = 0; r < h; r++)
    if (y + r >= 0 && y + r < SCREEN_H)
      memcpy(framebuffer + (y + r) * SCREEN_W + x, px + r * w, (size_t)w * sizeof(uint16_t));
  if (y + h >= SCREEN_H) {
    static uint32_t rgba[SCREEN_W * SCREEN_H];
    for (int i = 0; i < SCREEN_W * SCREEN_H; i++) {
      uint16_t c = framebuffer[i];
      uint8_t r = (uint8_t)(((c >> 11) & 31) * 255 / 31);
      uint8_t g = (uint8_t)(((c >> 5) & 63) * 255 / 63);
      uint8_t b = (uint8_t)((c & 31) * 255 / 31);
      rgba[i] = 0xFF000000u | ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
    }
    SDL_UpdateTexture(texture, NULL, rgba, SCREEN_W * (int)sizeof(uint32_t));
    SDL_RenderClear(renderer);
    SDL_RenderCopy(renderer, texture, NULL, NULL);
    SDL_RenderPresent(renderer);
  }
}
bool plat_save(const char *name, const void *data, uint32_t len) {
  char path[512]; snprintf(path, sizeof path, "save/%s", name);
  FILE *f = fopen(path, "wb"); if (!f) return false;
  bool ok = fwrite(data, 1, len, f) == len; fclose(f);
#ifdef __EMSCRIPTEN__
  EM_ASM(FS.syncfs(false, function(err) { if (err) console.error(err); }););
#endif
  return ok;
}
static uint8_t loaded[4][1 << 16];
static int next_load;
const uint8_t *plat_load(const char *name, uint32_t *len) {
  char path[512]; snprintf(path, sizeof path, "save/%s", name);
  FILE *f = fopen(path, "rb"); if (!f) return NULL;
  uint8_t *b = loaded[next_load++ & 3];
  *len = (uint32_t)fread(b, 1, sizeof loaded[0], f); fclose(f); return b;
}
bool plat_remove(const char *name) {
  char path[512]; snprintf(path, sizeof path, "save/%s", name);
  bool ok = remove(path) == 0;
#ifdef __EMSCRIPTEN__
  EM_ASM(FS.syncfs(false, function(err) { if (err) console.error(err); }););
#endif
  return ok;
}
void plat_begin(void) {
  SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS | SDL_INIT_TIMER);
  SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
#ifdef __EMSCRIPTEN__
  SDL_SetHint(SDL_HINT_EMSCRIPTEN_KEYBOARD_ELEMENT, "#canvas");
#endif
  window = SDL_CreateWindow("Among Us - PC Edition", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                            960, 720, SDL_WINDOW_RESIZABLE);
  renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
  if (!renderer) renderer = SDL_CreateRenderer(window, -1, 0);
  SDL_RenderSetLogicalSize(renderer, SCREEN_W, SCREEN_H);
  texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, SCREEN_W, SCREEN_H);
#ifdef __EMSCRIPTEN__
  EM_ASM({
    try { FS.mkdir('/save'); } catch(e) {}
    try { FS.mount(IDBFS, {}, '/save'); } catch(e) {}
    FS.syncfs(true, function(err) { if (err) console.error('Save sync failed', err); });
  });
#else
  mkdir("save", 0755);
#endif
}
int plat_end(void) {
  if (texture) SDL_DestroyTexture(texture);
  if (renderer) SDL_DestroyRenderer(renderer);
  if (window) SDL_DestroyWindow(window);
  SDL_Quit(); return 0;
}

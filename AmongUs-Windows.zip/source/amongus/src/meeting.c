/* Among Us: the meeting (MeetingHud): discussion, then voting with a skip, the votes shown, then the ejection.
 * The bots talk in short lines, as the game's quick chat does. */
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "game.h"
#include "gfx.h"
#include "world.h"

#define WHITE 0xFFFF

static uint8_t memory_open, memory_detail, memory_bot, memory_scroll;

bool meeting_memory_is_open(void) { return memory_open != 0; }

/* One source of truth for the player's quick chat. Every phrase is visible,
   selectable and uses the same Line kinds as bot dialogue. */
#define CHAT_COUNT 39
#define CHAT_VISIBLE 5
static const uint8_t chat_kinds[CHAT_COUNT] = {
  L_PLAYER_WITH, L_PLAYER_SUS, L_PLAYER_IN_ROOM, L_PLAYER_SEEN_ROOM,
  L_PLAYER_VENT, L_PLAYER_KILL, L_PLAYER_TRUST, L_PLAYER_NOT_TRUST,
  L_PLAYER_ALIBI, L_PLAYER_IN_ROOM_ONLY, L_PLAYER_DOING_TASKS, L_PLAYER_WHERE,
  L_PLAYER_SEEN_IN_ROOM, L_PLAYER_NOT_WITH, L_PLAYER_LEFT_ROOM, L_ASK_CONFIRM,
  L_ASK_WHERE, L_PLAYER_CONFIRM, L_PLAYER_NO_CONFIRM, L_PLAYER_LYING,
  L_PLAYER_AGREE, L_PLAYER_DISAGREE, L_PLAYER_VOTE, L_SKIP, L_PLAYER_NEED_INFO,
  L_PLAYER_BODY_IN_ROOM, L_PLAYER_DEAD, L_PLAYER_SAFE, L_PLAYER_FOLLOW,
  L_PLAYER_LAST, L_PLAYER_LAST_IN_ROOM, L_WHO, L_WHERE, L_NOT_ME, L_BUTTON, L_SKIP,
  L_NEAR_BODY, L_SAW_WITH, L_SCANNED
};
static const uint8_t chat_needs_room[CHAT_COUNT] = {
  0,0,1,1,0,0,0,0,0,1,0,0,1,0,1,1,0,1,0,0,0,0,0,0,0,1,0,0,0,0,1,
  0,0,0,0,0,1,1,0
};
static const uint8_t chat_needs_player[CHAT_COUNT] = {
  1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,
  0,0,0,0,0,1,1,1
};
static const char *const chat_labels[CHAT_COUNT] = {
  "I was with [player]", "I suspect [player]", "I was in [place]",
  "I saw [player] near [place]", "I saw [player] vent", "I saw [player] kill",
  "I trust [player]", "I don't trust [player]", "[player] has an alibi",
  "I was in [place]", "I was doing tasks", "Where was [player]?",
  "I saw [player] in [place]", "I was NOT with [player]", "[player] left [place]",
  "Confirm [player] in [place]?", "[player], where were you?",
  "I can confirm [player] was in [place]", "Can't confirm [player]", "[player] is lying",
  "I agree with [player]", "I disagree with [player]", "I'll vote [player]",
  "Skip vote", "Need more information", "Body found in [place]",
  "[player] is dead", "[player] is safe", "[player] followed me",
  "[player] was nearby", "Last saw [player] in [place]",
  "Who?", "Where?", "Not me", "I called this meeting", "Skip",
  "[player] was near body", "[player] was with victim", "[player] was scanned"
};

static float meeting_discussion_duration(void) {
  int living_bots = 0;
  for (int i = 0; i < g.nplayers; i++)
    if (i != g.me && g.p[i].alive) living_bots++;
  float minimum = 15.0f + living_bots * 2.0f;
  return g.opt.discuss > minimum ? (float)g.opt.discuss : minimum;
}

static const char *memory_personality(uint8_t p) {
  static const char *const names[] = {"Detective", "Strategist", "Skeptic", "Follower", "Leader", "Discreet"};
  return p < 6 ? names[p] : "Unknown";
}

void hud_keys(const char *s);
void art_player(int color, float x, float y, float scale, bool flip, int alpha);
void art_meeting_bg(void);
void art_plate(int x, int y, int i, bool sel, bool voted, bool dead);
void art_vote_icon(int x, int y, int color, bool anon);
void art_skip(int x, int y, bool sel);
void art_confirm(int x, int y, bool yes);

const char *line_text(const Line *l, char *b, int n) {
  char an[24]; player_name(l->a, an, sizeof an);
  const char *a = l->a < MAXP ? an : "";
  const char *r = l->b < N_ROOMS ? ROOM_NAMES[l->b] : "";
  switch (l->kind) {
  case L_BODY_IN: snprintf(b, (size_t)n, "%s is dead. Body in %s", a, r); break;
  case L_NEAR_BODY: snprintf(b, (size_t)n, "%s was near the body in %s", a, r); break;
  case L_SAW_KILL: snprintf(b, (size_t)n, "I saw %s kill in %s!", a, r); break;
  case L_SAW_VENT: snprintf(b, (size_t)n, "%s vented in %s!", a, r); break;
  case L_WAS_IN:
    if (l->a == R_HALLWAY) snprintf(b, (size_t)n, "I was doing tasks");
    else snprintf(b, (size_t)n, "I was in %s doing tasks", l->a < N_ROOMS ? ROOM_NAMES[l->a] : "");
    break;
  case L_WITH:
    if (l->b == R_HALLWAY) snprintf(b, (size_t)n, "I was with %s", a);
    else snprintf(b, (size_t)n, "I was with %s in %s", a, r);
    break;
  case L_SUS: snprintf(b, (size_t)n, "%s is sus", a); break;
  case L_WHO: snprintf(b, (size_t)n, "Who?"); break;
  case L_WHERE: snprintf(b, (size_t)n, "Where?"); break;
  case L_SKIP: snprintf(b, (size_t)n, "Skip"); break;
  case L_NOT_ME: snprintf(b, (size_t)n, "Not me"); break;
  case L_SCANNED: snprintf(b, (size_t)n, "%s scanned, they're safe", a); break;
  case L_BUTTON: snprintf(b, (size_t)n, "I called it. Anyone sus?"); break;
  case L_PLAYER_SUS: snprintf(b, (size_t)n, "%s is sus", a); break;
  case L_PLAYER_SAFE: snprintf(b, (size_t)n, "%s is safe", a); break;
  case L_PLAYER_VENT: snprintf(b, (size_t)n, "I saw %s vent!", a); break;
  case L_PLAYER_KILL: snprintf(b, (size_t)n, "I saw %s kill someone!", a); break;
  case L_PLAYER_WITH: snprintf(b, (size_t)n, "I was with %s", a); break;
  case L_PLAYER_FOLLOW: snprintf(b, (size_t)n, "%s was following me", a); break;
  case L_PLAYER_LAST: snprintf(b, (size_t)n, "%s was last seen nearby", a); break;
  case L_PLAYER_TRUST: snprintf(b, (size_t)n, "I trust %s", a); break;
  case L_PLAYER_ALIBI: snprintf(b, (size_t)n, "%s has an alibi", a); break;
  case L_PLAYER_VOTE: snprintf(b, (size_t)n, "I will vote for %s", a); break;
  case L_PLAYER_IN_ROOM: snprintf(b, (size_t)n, "I was in %s with %s", r, a); break;
  case L_PLAYER_SEEN_ROOM: snprintf(b, (size_t)n, "I saw %s near %s", a, r); break;
  case L_PLAYER_IN_ROOM_ONLY: snprintf(b, (size_t)n, "I was in %s", r); break;
  case L_PLAYER_DOING_TASKS: snprintf(b, (size_t)n, "I was doing tasks"); break;
  case L_PLAYER_NOT_TRUST: snprintf(b, (size_t)n, "I don't trust %s", a); break;
  case L_PLAYER_WHERE: snprintf(b, (size_t)n, "Where was %s?", a); break;
  case L_ASK_WHERE: snprintf(b, (size_t)n, "%s, where were you?", a); break;
  case L_ASK_CONFIRM: snprintf(b, (size_t)n, "Can anyone confirm %s was in %s?", a, r); break;
  case L_ANSWER_WHERE: snprintf(b, (size_t)n, "I was in %s", l->a < N_ROOMS ? ROOM_NAMES[l->a] : "an unknown place"); break;
  case L_CONFIRM: snprintf(b, (size_t)n, "I saw %s in %s", a, r); break;
  case L_NO_CONFIRM: snprintf(b, (size_t)n, "I cannot confirm %s's alibi", a); break;
  case L_PLAYER_SEEN_IN_ROOM: snprintf(b, (size_t)n, "I saw %s in %s", a, r); break;
  case L_PLAYER_NOT_WITH: snprintf(b, (size_t)n, "I was NOT with %s", a); break;
  case L_PLAYER_LEFT_ROOM: snprintf(b, (size_t)n, "I saw %s leave %s", a, r); break;
  case L_PLAYER_CONFIRM: snprintf(b, (size_t)n, "I can confirm %s was in %s", a, r); break;
  case L_PLAYER_NO_CONFIRM: snprintf(b, (size_t)n, "I can't confirm %s's story", a); break;
  case L_PLAYER_LYING: snprintf(b, (size_t)n, "I think %s is lying", a); break;
  case L_PLAYER_AGREE: snprintf(b, (size_t)n, "I agree with %s", a); break;
  case L_PLAYER_DISAGREE: snprintf(b, (size_t)n, "I disagree with %s", a); break;
  case L_PLAYER_LAST_IN_ROOM: snprintf(b, (size_t)n, "I last saw %s in %s", a, r); break;
  case L_PLAYER_NEED_INFO: snprintf(b, (size_t)n, "I need more information"); break;
  case L_PLAYER_BODY_IN_ROOM: snprintf(b, (size_t)n, "%s is dead. Body found in %s", a, r); break;
  case L_PLAYER_DEAD: snprintf(b, (size_t)n, "%s is dead", a); break;
  case L_SAW_WITH:
    if (l->b == R_HALLWAY || g.reported == NONE) snprintf(b, (size_t)n, "%s was with %s", a, COLOR_NAMES[g.p[g.reported < MAXP ? g.reported : 0].color]);
    else snprintf(b, (size_t)n, "%s was with %s in %s", a, COLOR_NAMES[g.p[g.reported].color], r);
    break;
  default: b[0] = 0;
  }
  return b;
}

static void finish_votes(void) {
  int counts[MAXP + 1] = {0};
  for (int i = 0; i < g.nplayers; i++)
    if (g.p[i].alive && g.votes[i] != NONE) counts[g.votes[i]]++;
  int best = -1, bc = 0, tie = 0;
  for (int k = 0; k <= SKIP; k++) {
    if (counts[k] > bc) bc = counts[k], best = k, tie = 0;
    else if (counts[k] == bc && bc) tie = 1;
  }
  g.tie = (uint8_t)tie;
  g.ejected = (best >= 0 && best != SKIP && !tie) ? (uint8_t)best : NONE;
}

static int living_voters(void) {
  int n = 0;
  for (int i = 0; i < g.nplayers; i++) n += g.p[i].alive;
  return n;
}

static void after_meeting(void) {
  memory_open = 0; memory_detail = 0; memory_scroll = 0;
  /* Hard bots remember accusations that were disproved by a confirmed innocent ejection.
     This lowers the speaker's credibility; it is not treated as proof of impostor status. */
  if (g.ejected != NONE && g.opt.confirm && !g.p[g.ejected].imp) {
    for (int k = 0; k < g.nlines; k++) {
      Line *L = &g.lines[k];
      if ((L->kind == L_PLAYER_KILL || L->kind == L_SAW_KILL || L->kind == L_PLAYER_VENT ||
           L->kind == L_SAW_VENT || L->kind == L_SUS || L->kind == L_NEAR_BODY ||
           L->kind == L_SAW_WITH || L->kind == L_PLAYER_SUS || L->kind == L_PLAYER_NOT_TRUST ||
           L->kind == L_PLAYER_LYING) && L->a == g.ejected && L->who < g.nplayers) {
        for (int i = 0; i < g.nplayers; i++) if (is_bot(i) && g.p[i].alive && !g.p[i].imp) {
          Bot *B = &g.p[i].bot;
          int v = B->credibility[L->who] - 32;
          B->credibility[L->who] = (int8_t)(v < -100 ? -100 : v);
          if (B->false_claims[L->who] < 255) B->false_claims[L->who]++;
          int suspicion = B->sus[L->who] + 32;
          B->sus[L->who] = (int8_t)(suspicion > 100 ? 100 : suspicion);
          if (L->who != i) {
            int cleared = B->sus[g.ejected] - 25;
            B->sus[g.ejected] = (int8_t)(cleared < -100 ? -100 : cleared);
          }
        }
      }
    }
  }
  /* back in the cafeteria, as after every meeting */
  if (g.ejected != NONE) { g.p[g.ejected].alive = 0; if (g.ejection_count < 255) g.ejection_count++; }
  for (int b = 0; b < MAXP; b++) g.bodies[b].on = 0;
  int n = g.nplayers;
  for (int i = 0; i < n; i++) {
    Player *P = &g.p[i];
    spawn_at_table(i);
    P->kill_cd = kill_cooldown();
    P->busy = 0;
    Bot *B = &P->bot;
    B->state = 0;
    B->plen = 0;
    B->near_body = B->found_body = NONE;
    if (B->saw_kill != NONE && !g.p[B->saw_kill].alive) B->saw_kill = NONE;
    if (B->saw_vent != NONE && !g.p[B->saw_vent].alive) B->saw_vent = NONE;
    B->t = 0.5f + rnd_f();
  }
  g.cam = (V2){g.p[g.me].pos.x, g.p[g.me].pos.y + FEET_Y};
  g.emergency_cd = g.opt.meet_cd;
  g.task_bar = tasks_progress();
  g.overlay = O_NONE;
}

/* The meeting screen shows ten players at a time (two columns, five rows).
 * This keeps the voting plates readable even in a 31-player lobby. */
#define VOTE_PAGE_SIZE 10
#define VOTE_ROWS 5
#define PLATE_X(i) (18 + ((i) & 1) * 134)
#define PLATE_Y(i) (41 + ((i) >> 1) * 27)
#define SKIP_X 18
#define SKIP_Y 177

static int move_sel(int s, uint32_t pressed) {
  int n = g.nplayers;
  int pages = (n + VOTE_PAGE_SIZE - 1) / VOTE_PAGE_SIZE;
  if (s == SKIP) {
    if (pressed & K_UP) return n - 1;
    return SKIP;
  }

  int page = s / VOTE_PAGE_SIZE;
  int local = s % VOTE_PAGE_SIZE;
  int count = n - page * VOTE_PAGE_SIZE;
  if (count > VOTE_PAGE_SIZE) count = VOTE_PAGE_SIZE;
  int row = local / 2, col = local & 1;

  /* Left/right may switch columns, but never change the page. */
  if (pressed & K_LEFT) {
    if (col) col = 0;
  }
  if (pressed & K_RIGHT) {
    if (!col && local + 1 < count) col = 1;
  }
  if (pressed & K_UP) {
    if (row > 0) row--;
    else if (page > 0) {
      page--;
      int prev_count = n - page * VOTE_PAGE_SIZE;
      if (prev_count > VOTE_PAGE_SIZE) prev_count = VOTE_PAGE_SIZE;
      row = (prev_count - 1) / 2;
    }
  }
  if (pressed & K_DOWN) {
    if (row + 1 < VOTE_ROWS && row * 2 + 2 + col < count) row++;
    else if (page + 1 < pages) page++, row = 0;
    else return SKIP;
  }

  int new_count = n - page * VOTE_PAGE_SIZE;
  if (new_count > VOTE_PAGE_SIZE) new_count = VOTE_PAGE_SIZE;
  local = row * 2 + col;
  if (local >= new_count) local = new_count - 1;
  return page * VOTE_PAGE_SIZE + local;
}

/* VAR memory inspector: deliberately exposes only the bot's observations and beliefs.
   It never reads or displays Player.imp, roles, tasks, or hidden game state. */
static int memory_bot_count(void) {
  int n = 0;
  for (int i = 0; i < g.nplayers; i++) if (i != g.me) n++;
  return n;
}
static int memory_bot_at(int index) {
  for (int i = 0; i < g.nplayers; i++) if (i != g.me && index-- == 0) return i;
  return g.me;
}
static void memory_tick(uint32_t pressed) {
  if (!memory_open) {
    if (pressed & K_VAR) {
      memory_open = 1; memory_detail = 0; memory_bot = 0; memory_scroll = 0;
    }
    return;
  }
  if (pressed & K_VAR) { memory_open = 0; return; }
  if (pressed & K_BACK) {
    if (memory_detail) memory_detail = 0;
    else memory_open = 0;
    return;
  }
  if (!memory_detail) {
    int count = memory_bot_count();
    if (count <= 0) return;
    if (pressed & K_UP) memory_bot = (uint8_t)((memory_bot + count - 1) % count);
    if (pressed & K_DOWN) memory_bot = (uint8_t)((memory_bot + 1) % count);
    if (pressed & (K_OK | K_EXE)) { memory_detail = 1; memory_scroll = 0; }
  } else {
    int max_scroll = g.nplayers > 8 ? g.nplayers - 8 : 0;
    if ((pressed & K_UP) && memory_scroll) memory_scroll--;
    if ((pressed & K_DOWN) && memory_scroll < max_scroll) memory_scroll++;
  }
}
static void memory_draw(void) {
  gfx_fill(8, 8, 304, 224, rgb565(0x101C2C), 252);
  gfx_rect(8, 8, 304, 224, 2, rgb565(0x76B9E8));
  gfx_text(FONT_BIG, 160, 24, "BOT MEMORY", WHITE, 0, 0, 1);
  if (!memory_detail) {
    gfx_text(FONT_SMALL, 160, 39, "Select a bot  |  VAR / Back: close", rgb565(0xB9D9F2), 0, 0, 1);
    int count = memory_bot_count();
    int first = memory_bot > 8 ? memory_bot - 8 : 0;
    if (first + 10 > count) first = count > 10 ? count - 10 : 0;
    for (int row = 0; row < 10 && first + row < count; row++) {
      int id = memory_bot_at(first + row); char name[24], line[48];
      player_name(id, name, sizeof name);
      snprintf(line, sizeof line, "%c %s%s", first + row == memory_bot ? '>' : ' ', name,
               g.p[id].alive ? "" : "  (dead)");
      gfx_text(FONT_SMALL, 30, 59 + row * 14, line,
               first + row == memory_bot ? rgb565(0xFFE08A) : WHITE, 0, 0, 0);
    }
    gfx_text(FONT_SMALL, 160, 218, "UP/DOWN select   OK inspect   Back close", WHITE, 0, 0, 1);
  } else {
    int id = memory_bot_at(memory_bot); Bot *B = &g.p[id].bot;
    char name[24], title[48]; player_name(id, name, sizeof name);
    snprintf(title, sizeof title, "%s | %s", name, memory_personality(B->personality));
    gfx_text(FONT_SMALL, 160, 40, title, rgb565(0xFFE08A), 0, 0, 1);
    int shown = 0, skipped = 0;
    for (int j = 0; j < g.nplayers && shown < 7; j++) {
      if (j == id) continue;
      if (skipped < memory_scroll) { skipped++; continue; }
      int row = shown++, y = 54 + row * 22;
      char target[24], line1[64], line2[64]; player_name(j, target, sizeof target);
      int trust = B->credibility[j], sus = B->sus[j];
      snprintf(line1, sizeof line1, "%s  Trust %+d  Sus %+d  Relation %+d", target, trust, sus, B->relation[j]);
      if (B->seen_t[j] > 0 && B->seen_room[j] < N_ROOMS) {
        float age = g.t - B->seen_t[j];
        if (age < 0) age = 0;
        snprintf(line2, sizeof line2, "Seen %s %.0fs ago | together %.0fs | false claims %u",
                 ROOM_NAMES[B->seen_room[j]], age, B->with_t[j], (unsigned)B->false_claims[j]);
      } else {
        snprintf(line2, sizeof line2, "Position unknown | together %.0fs | false claims %u",
                 B->with_t[j], (unsigned)B->false_claims[j]);
      }
      gfx_text(FONT_SMALL, 20, y, line1, WHITE, 0, 0, 0);
      gfx_text(FONT_SMALL, 26, y + 10, line2, rgb565(0xB9D9F2), 0, 0, 0);
    }
    gfx_text(FONT_SMALL, 160, 218, "UP/DOWN scroll   Back: bot list", WHITE, 0, 0, 1);
  }
}

void meeting_tick(uint32_t keys, uint32_t pressed) {
  (void)keys;
  /* + freezes time and bot activity, but never locks the human player's controls. */
  if (pressed & K_PLUS) g.meet_paused = !g.meet_paused;
  const bool paused = g.meet_paused != 0;
  if (!paused) {
    g.meet_t += DT;
    bot_meeting_tick();
  }
  Player *M = &g.p[g.me];
  memory_tick(pressed);
  if (memory_open) return;
  /* Quick chat: choose a phrase, then fill its placeholders one at a time. */
  if (g.meet_stage == 0 && M->alive) {
    if (g.chat_open) {
      int choice = g.chat_choice % CHAT_COUNT;
      if (pressed & K_UP) {
        if (g.chat_stage == 0) g.chat_choice = (uint8_t)((choice + CHAT_COUNT - 1) % CHAT_COUNT);
        else if (g.chat_stage == 1) g.chat_room = (uint8_t)((g.chat_room + N_ROOMS - 1) % N_ROOMS);
        else if (g.chat_stage == 2) {
          for (int k = 0; k < g.nplayers; k++) {
            int t = ((int)g.chat_target + g.nplayers - 1) % g.nplayers;
            g.chat_target = (uint8_t)t;
            if (t != g.me && (g.p[t].alive || choice == 25 || choice == 26)) break;
          }
        }
      }
      if (pressed & K_DOWN) {
        if (g.chat_stage == 0) g.chat_choice = (uint8_t)((choice + 1) % CHAT_COUNT);
        else if (g.chat_stage == 1) g.chat_room = (uint8_t)((g.chat_room + 1) % N_ROOMS);
        else if (g.chat_stage == 2) {
          for (int k = 0; k < g.nplayers; k++) {
            int t = ((int)g.chat_target + 1) % g.nplayers;
            g.chat_target = (uint8_t)t;
            if (t != g.me && (g.p[t].alive || choice == 25 || choice == 26)) break;
          }
        }
      }
      if (g.chat_stage == 2 && (pressed & (K_LEFT | K_RIGHT))) {
        int step = (pressed & K_RIGHT) ? 1 : -1;
        for (int k = 0; k < g.nplayers; k++) {
          int t = ((int)g.chat_target + g.nplayers + step) % g.nplayers;
          g.chat_target = (uint8_t)t;
          if (t != g.me && (g.p[t].alive || choice == 25 || choice == 26)) break;
        }
      }
      if (pressed & (K_OK | K_EXE)) {
        if (g.chat_stage == 0) {
          g.chat_stage = chat_needs_room[choice] ? 1 : (chat_needs_player[choice] ? 2 : 3);
        } else if (g.chat_stage == 1) {
          g.chat_stage = chat_needs_player[choice] ? 2 : 3;
        } else if (g.chat_stage == 2) {
          if (g.chat_target != g.me && g.chat_target < g.nplayers && (g.p[g.chat_target].alive || choice == 25 || choice == 26)) g.chat_stage = 3;
        }
        if (g.chat_stage == 3) {
          /* Preview first; a second confirmation is required to send. */
          g.chat_stage = 4;
        } else if (g.chat_stage == 4) {
          int target = g.chat_target;
          if (!chat_needs_player[choice] || (target < g.nplayers && target != g.me && (g.p[target].alive || choice == 25 || choice == 26))) {
            if (g.nlines >= MAX_LINES) { memmove(g.lines, g.lines + 1, sizeof g.lines[0] * (MAX_LINES - 1)); g.nlines--; }
            int a = chat_needs_player[choice] ? target : 0;
            int b = chat_needs_room[choice] ? g.chat_room : 0;
            g.lines[g.nlines++] = (Line){(uint8_t)g.me, chat_kinds[choice], (uint8_t)a, (uint8_t)b};
            /* Every quick-chat line is delivered to the bots. Messages without
               a player placeholder use -1 instead of accidentally targeting player 0. */
            bot_hear_player(chat_kinds[choice], chat_needs_player[choice] ? target : -1, b);
            if (chat_kinds[choice] == L_ASK_WHERE || chat_kinds[choice] == L_PLAYER_WHERE)
              bot_player_question(L_ASK_WHERE, target, b);
            else if (chat_kinds[choice] == L_ASK_CONFIRM)
              bot_player_question(L_ASK_CONFIRM, target, b);
          }
          g.chat_open = 0;
          g.chat_stage = 0;
        }
      }
      if (pressed & K_BACK) {
        if (g.chat_stage > 0) g.chat_stage = 0;
        else g.chat_open = 0;
      }
      return;
    }
#ifdef __ANDROID__
    if (pressed & K_CHAT) {
#else
    if (pressed & K_EXE) {
#endif
      g.chat_open = 1;
      g.chat_choice = 0;
      g.chat_stage = 0;
      g.chat_room = R_CAFETERIA;
      g.chat_target = (uint8_t)((g.me + 1) % g.nplayers);
      return;
    }
  }
  if (!paused && g.meet_stage == 0 && g.meet_t >= meeting_discussion_duration()) g.meet_stage = 1, g.meet_t = 0;
  if (pressed & K_TOOL) {
    g.line_shown = g.line_shown ? 0 : 1;
    return;
  }
  if (g.line_shown && (pressed & K_UP)) {
    int max_scroll = g.nlines > 10 ? g.nlines - 10 : 0;
    if (g.chat_scroll < max_scroll) g.chat_scroll++;
    return;
  }
  if (g.line_shown && (pressed & K_DOWN)) {
    if (g.chat_scroll) g.chat_scroll--;
    return;
  }
  if (g.line_shown && (pressed & K_BACK)) {
    g.line_shown = 0;
    return;
  }
  /* Android: keep the player page browsable during discussion and vote processing.
     Page changes are vertical only; left/right never change pages. */
  if (g.meet_stage != 1 && !g.line_shown && (pressed & (K_UP | K_DOWN))) {
    int s = g.sel & 31;
    if (s >= g.nplayers) s = 0;
    s = move_sel(s, pressed & (K_UP | K_DOWN));
    g.sel = (uint8_t)s;
  }
  if (g.meet_stage == 1) {
    /* Bots stay frozen during a pause; the human can still cast their vote. */
    if (!paused) bot_votes();
    /* the player's vote: a plate or Skip, then the tick */
    if (M->alive && g.votes[g.me] == NONE && !g.line_shown) {
      int s = g.sel & 31;
      bool confirm = g.sel & 32;
      if (s > SKIP) s = 0;
      if (!confirm) {
        s = move_sel(s, pressed);
        bool ok = s == SKIP || (s < g.nplayers && g.p[s].alive);
        if ((pressed & (K_OK | K_EXE)) && ok) confirm = true;
      } else {
        if (pressed & (K_OK | K_EXE)) g.votes[g.me] = (uint8_t)s, confirm = false;
        if (pressed & (K_BACK | K_LEFT | K_RIGHT | K_UP | K_DOWN)) confirm = false;
      }
      g.sel = (uint8_t)(s | (confirm ? 32 : 0));
    }
    int voted = 0;
    for (int i = 0; i < g.nplayers; i++) voted += g.p[i].alive && g.votes[i] != NONE;
    if ((voted >= living_voters() && g.meet_t >= 20.0f) ||
        (!paused && g.meet_t >= g.opt.vote * 5)) {
      finish_votes();
      g.meet_stage = 2;
      g.meet_t = 0;
      g.line_shown = 0;
    }
  } else if (g.meet_stage == 2 && !paused && g.meet_t >= 5) {
    after_meeting();
    g.screen = S_EJECT;
    g.screen_t = 0;
  }
}

static const char *stage_text(char *b, int n) {
  if (g.meet_stage == 0) snprintf(b, (size_t)n, "Voting Begins In: %ds", (int)ceilf(meeting_discussion_duration() - g.meet_t));
  else if (g.meet_stage == 1) snprintf(b, (size_t)n, "Voting Ends In: %ds", (int)ceilf(g.opt.vote * 5 - g.meet_t));
  else snprintf(b, (size_t)n, "Proceeding In: %ds", (int)ceilf(5 - g.meet_t));
  return b;
}

/* a chat line: the speaker's head, name and words */
static void chat_line(const Line *l, int x, int y, uint16_t text) {
  char b[64];
  const Player *P = &g.p[l->who];
  gfx_spr(pic(PIC_VOTE_ICON), x + 5, y - 4, false, color_pal[P->color], 256);
  char speaker[24]; player_name(l->who, speaker, sizeof speaker);
  /* When the human is an impostor, reveal teammate names in red in meeting chat. */
  uint16_t name_color = (g.p[g.me].imp && P->imp) ? rgb565(0xFF4B55) : 0xFFFF;
  int w = gfx_text(FONT_SMALL, x + 13, y, speaker, name_color, 0x0000, 1, 0);
  uint16_t line_color = text;
  if (g.p[g.me].imp && l->a < g.nplayers && g.p[l->a].imp &&
      (l->kind == L_SUS || l->kind == L_PLAYER_SUS || l->kind == L_PLAYER_SAFE ||
       l->kind == L_PLAYER_TRUST || l->kind == L_PLAYER_ALIBI ||
       l->kind == L_PLAYER_CONFIRM || l->kind == L_PLAYER_SEEN_IN_ROOM ||
       l->kind == L_PLAYER_LAST_IN_ROOM || l->kind == L_PLAYER_LEFT_ROOM ||
       l->kind == L_PLAYER_LYING || l->kind == L_PLAYER_VENT ||
       l->kind == L_PLAYER_KILL || l->kind == L_PLAYER_WITH ||
       l->kind == L_PLAYER_FOLLOW || l->kind == L_PLAYER_NOT_TRUST ||
       l->kind == L_BODY_IN || l->kind == L_NEAR_BODY || l->kind == L_SAW_KILL ||
       l->kind == L_SAW_VENT || l->kind == L_WITH || l->kind == L_PLAYER_IN_ROOM ||
       l->kind == L_PLAYER_SEEN_ROOM || l->kind == L_PLAYER_VOTE ||
       l->kind == L_PLAYER_BODY_IN_ROOM || l->kind == L_PLAYER_DEAD ||
       l->kind == L_PLAYER_WHERE || l->kind == L_ASK_WHERE ||
       l->kind == L_ASK_CONFIRM || l->kind == L_CONFIRM || l->kind == L_NO_CONFIRM ||
       l->kind == L_PLAYER_NO_CONFIRM || l->kind == L_PLAYER_AGREE ||
       l->kind == L_PLAYER_DISAGREE || l->kind == L_PLAYER_LAST ||
       l->kind == L_PLAYER_NOT_WITH))
    line_color = rgb565(0xFF737B);
  gfx_text(FONT_SMALL, x + 17 + w, y, line_text(l, b, sizeof b), line_color, 0x0000, 1, 0);
}

void meeting_draw(void) {
  art_meeting_bg();
  if (memory_open) { memory_draw(); return; }
  char b[64];
  if (g.meet_paused) {
    /* Compact status capsule: dark glass, warm outline and a clear pause symbol. */
    gfx_fill(88, 5, 144, 31, rgb565(0x101820), 242);
    gfx_rect(88, 5, 144, 31, 2, rgb565(0xF0A34A));
    gfx_disc(105, 20, 9, rgb565(0xF0A34A), 256);
    gfx_fill(102, 15, 2, 10, rgb565(0x18212B), 256);
    gfx_fill(106, 15, 2, 10, rgb565(0x18212B), 256);
    gfx_text(FONT_MID, 119, 17, "PAUSED", WHITE, 0, 0, 0);
    gfx_text(FONT_SMALL, 119, 27, "BOTS & TIMER FROZEN", rgb565(0xF4C58E), 0, 0, 0);
  }
  int sel = g.sel & 31;
  bool confirm = g.sel & 32;
  const Player *M = &g.p[g.me];
  bool can_vote = g.meet_stage == 1 && M->alive && g.votes[g.me] == NONE && !g.line_shown;
  int page = sel < g.nplayers ? sel / VOTE_PAGE_SIZE : (g.nplayers - 1) / VOTE_PAGE_SIZE;
  int first_player = page * VOTE_PAGE_SIZE;
  int last_player = first_player + VOTE_PAGE_SIZE;
  if (last_player > g.nplayers) last_player = g.nplayers;
  for (int i = first_player; i < last_player; i++) {
    int local = i - first_player;
    int x = PLATE_X(local), y = PLATE_Y(local);
    if (!gfx_rows(y - 2, y + 26)) continue;
    art_plate(x, y, i, can_vote && sel == i, g.votes[i] != NONE && g.meet_stage >= 1 && g.p[i].alive, !g.p[i].alive);
    if (g.meet_stage == 2) {
      /* Show at most ten vote markers on a plate; summarize the rest. */
      int k = 0;
      for (int v = 0; v < g.nplayers; v++)
        if (g.p[v].alive && g.votes[v] == i) {
          if (k < 10)
            art_vote_icon(x + 82 + 10 * (k % 5), y + 5 + 9 * (k / 5), g.p[v].color, g.opt.anon);
          k++;
        }
      if (k > 10) {
        char more[16];
        snprintf(more, sizeof more, "+%d", k - 10);
        gfx_text(FONT_SMALL, x + 124, y + 17, more, WHITE, 0, 1, 0);
      }
    }
    if (can_vote && sel == i && confirm) art_confirm(x + 84, y + 2, true);
  }
  snprintf(b, sizeof b, "Players %d-%d / %d", first_player + 1, last_player, g.nplayers);
  gfx_text(FONT_SMALL, 282, 25, b, 0xFFFF, 0x0000, 1, 2);
  /* Skip, the clock, the last thing said */
  art_skip(SKIP_X, SKIP_Y, can_vote && sel == SKIP);
  if (can_vote && sel == SKIP && confirm) art_confirm(SKIP_X + 72, SKIP_Y - 2, true);
  if (g.meet_stage == 2) {
    gfx_spr(pic(PIC_UI_SKIPPEDVOTINGTALLY), SKIP_X + 20, SKIP_Y + 8, false, NULL, 256);
    int k = 0;
    for (int v = 0; v < g.nplayers; v++)
      if (g.p[v].alive && g.votes[v] == SKIP) {
        if (k < 12) art_vote_icon(SKIP_X + 48 + 10 * k, SKIP_Y + 8, g.p[v].color, g.opt.anon);
        k++;
      }
    if (k > 12) {
      char more[16];
      snprintf(more, sizeof more, "+%d", k - 12);
      gfx_text(FONT_SMALL, SKIP_X + 174, SKIP_Y + 12, more, WHITE, 0, 1, 0);
    }
  }
  gfx_text(FONT_MID, 282, SKIP_Y + 12, stage_text(b, sizeof b), 0xFFFF, 0x0000, 1, 2);
  if (g.nlines && !g.line_shown) chat_line(&g.lines[g.nlines - 1], 18, 202, 0xFFFF);
  if (g.chat_open) {
    const char *const *choices = chat_labels;
    int t = g.chat_target < g.nplayers ? g.chat_target : 0;
    gfx_fill(20, 27, 280, 165, rgb565(0x0E1A2B), 248);
    gfx_rect(20, 27, 280, 165, 2, WHITE);
    gfx_text(FONT_BIG, 160, 40, "Quick Chat", WHITE, 0, 0, 1);
    if (g.chat_stage == 0) {
      gfx_text(FONT_SMALL, 160, 56, "Choose a sentence", 0xFFE0, 0, 0, 1);
      int first = (int)g.chat_choice - CHAT_VISIBLE / 2;
      if (first < 0) first = 0;
      if (first > CHAT_COUNT - CHAT_VISIBLE) first = CHAT_COUNT - CHAT_VISIBLE;
      for (int i = first; i < first + CHAT_VISIBLE; i++) {
        char row[64];
        snprintf(row, sizeof row, "%c %s", i == g.chat_choice ? '>' : ' ', choices[i]);
        gfx_text(FONT_SMALL, 34, 76 + (i - first) * 15, row, i == g.chat_choice ? 0xFFE0 : WHITE, 0, 0, 0);
      }
      char page[20];
      snprintf(page, sizeof page, "%d/%d", (int)g.chat_choice + 1, CHAT_COUNT);
      gfx_text(FONT_SMALL, 284, 56, page, 0xBDF7, 0, 0, 2);
      hud_keys("up/down choose   OK next   Back close");
    } else if (g.chat_stage == 1) {
      gfx_text(FONT_MID, 160, 65, "Choose a location", 0xFFE0, 0, 0, 1);
      gfx_text(FONT_BIG, 160, 103, ROOM_NAMES[g.chat_room % N_ROOMS], WHITE, 0, 0, 1);
      hud_keys("up/down location   OK validate   Back phrases");
    } else if (g.chat_stage == 4) {
      char label[64], preview[96];
      int ci = g.chat_choice % CHAT_COUNT;
      Line draft = {(uint8_t)g.me, chat_kinds[ci],
                    (uint8_t)(chat_needs_player[ci] ? t : 0),
                    (uint8_t)(chat_needs_room[ci] ? g.chat_room : 0)};
      line_text(&draft, preview, sizeof preview);
      if (t < g.nplayers && chat_needs_player[ci]) {
        char name[24]; player_name(t, name, sizeof name);
        snprintf(label, sizeof label, "To: %s", name);
      } else snprintf(label, sizeof label, "Ready to send");
      gfx_text(FONT_MID, 160, 67, "Confirm message?", 0xFFE0, 0, 0, 1);
      gfx_text(FONT_SMALL, 160, 88, preview, WHITE, 0, 0, 1);
      gfx_text(FONT_SMALL, 160, 105, label, rgb565(0xB9D9F2), 0, 0, 1);
      hud_keys("OK send   Back edit");
    } else {
      char name[24], label[40]; player_name(t, name, sizeof name);
      snprintf(label, sizeof label, "Player: %s", name);
      gfx_text(FONT_MID, 160, 65, "Choose a player", 0xFFE0, 0, 0, 1);
      gfx_text(FONT_BIG, 160, 103, label, WHITE, 0, 0, 1);
      hud_keys("up/down or left/right player   OK validate   Back phrases");
    }
    return;
  }
  if (g.line_shown) {
    /* the chat: the last lines said */
    gfx_fill(15, 20, 270, 187, rgb565(0x0E1A2B), 236);
    gfx_text(FONT_BIG, 150, 36, "Chat", 0xFFFF, 0x0000, 1, 1);
    int max_scroll = g.nlines > 10 ? g.nlines - 10 : 0;
    if (g.chat_scroll > max_scroll) g.chat_scroll = (uint8_t)max_scroll;
    int end = g.nlines - g.chat_scroll;
    int first = end > 10 ? end - 10 : 0;
    for (int k = first; k < end; k++) chat_line(&g.lines[k], 20, 56 + (k - first) * 15, 0xDEFB);
    if (!g.nlines) gfx_text(FONT_MID, 150, 110, "Nobody has said anything yet", 0xBDF7, 0, 0, 1);
    else { char page[32]; snprintf(page, sizeof page, "%d-%d / %d", first + 1, end, g.nlines); gfx_text(FONT_SMALL, 280, 36, page, 0xBDF7, 0, 0, 1); }
    hud_keys("up older   down newer   Back close");
    return;
  }
  if (can_vote)
    hud_keys(confirm ? "OK vote   Back cancel" : "arrows choose   OK vote   toolbox chat");
  else
    hud_keys(g.meet_stage == 0 ? "+ pause   EXE quick chat   toolbox chat" : "+ pause   toolbox chat");
}

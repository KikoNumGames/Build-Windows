/* Among Us: the bots (the game has none: these play as people do). Crewmates walk the ship to their tasks and do
 * them, report the bodies they see and remember who they saw where; impostors fake tasks, kill when nobody else
 * would see, vent, sabotage and join fixes. They know only what they saw. */
#include <math.h>
#include <string.h>
#include "game.h"
#include "world.h"

enum { B_IDLE, B_WALK, B_TASK, B_FIX, B_HUNT, B_VENT, B_WAIT, B_REPORT, B_BUTTON, B_SURVEIL };
/* what a walk is for */
enum { G_NONE, G_TASK, G_FAKE, G_FIX, G_BODY, G_BUTTON, G_WANDER, G_VENT, G_HUNT, G_ADMIN, G_CAMS };

int kill_target(int i);
int console_use(int i, int c);
void walk(int i, V2 dir);
static void go(int i, V2 to, int why, int cons);
static V2 stand(int c);

/* ---- the walking grid: Dijkstra from the goal, then down the distances ---- */

#define NCELLS (NAV_W * NAV_H)
static uint16_t ndist[NCELLS];
static uint16_t heap[NCELLS];
static int nheap;

static inline bool nav_ok(int x, int y) {
  return x >= 0 && y >= 0 && x < NAV_W && y < NAV_H && (NAV_BITS[y * ((NAV_W + 7) / 8) + (x >> 3)] >> (x & 7) & 1);
}
static inline V2 cell_pos(int c) {
  return (V2){NAV_X0 + (c % NAV_W + 0.5f) * NAV_CS, NAV_Y0 + (c / NAV_W + 0.5f) * NAV_CS};
}

static int nearest_cell(V2 p) {
  int cx = (int)floorf((p.x - NAV_X0) / NAV_CS), cy = (int)floorf((p.y - NAV_Y0) / NAV_CS);
  int best = -1;
  float bd = 1e9f;
  for (int r = 0; r <= 4 && best < 0; r++)
    for (int y = cy - r; y <= cy + r; y++)
      for (int x = cx - r; x <= cx + r; x++) {
        if (!nav_ok(x, y)) continue;
        V2 q = cell_pos(y * NAV_W + x);
        float d = (q.x - p.x) * (q.x - p.x) + (q.y - p.y) * (q.y - p.y);
        if (d < bd && (r > 2 || !ship_wall_between(p, q))) bd = d, best = y * NAV_W + x;
      }
  return best;
}

static void hpush(int c) {
  int i = nheap++;
  while (i > 0) {
    int p = (i - 1) / 2;
    if (ndist[heap[p]] <= ndist[c]) break;
    heap[i] = heap[p];
    i = p;
  }
  heap[i] = (uint16_t)c;
}
static int hpop(void) {
  int top = heap[0], last = heap[--nheap], i = 0;
  for (;;) {
    int ch = 2 * i + 1;
    if (ch >= nheap) break;
    if (ch + 1 < nheap && ndist[heap[ch + 1]] < ndist[heap[ch]]) ch++;
    if (ndist[heap[ch]] >= ndist[last]) break;
    heap[i] = heap[ch];
    i = ch;
  }
  if (nheap) heap[i] = (uint16_t)last;
  return top;
}

static bool door_blocks(V2 a, V2 b) {
  for (int d = 0; d < N_DOORS; d++) {
    if (!door_closed(d)) continue;
    const DoorRec *D = &DOORS[d];
    if (fabsf(a.x - D->x) > 2.5f || fabsf(a.y - D->y) > 2.5f) continue;
    for (int s = 0; s < 4; s++) {
      const Seg *S = &D->seg[s];
      float d1 = (S->x1 - S->x0) * (a.y - S->y0) - (S->y1 - S->y0) * (a.x - S->x0);
      float d2 = (S->x1 - S->x0) * (b.y - S->y0) - (S->y1 - S->y0) * (b.x - S->x0);
      if ((d1 > 0) == (d2 > 0)) continue;
      float d3 = (b.x - a.x) * (S->y0 - a.y) - (b.y - a.y) * (S->x0 - a.x);
      float d4 = (b.x - a.x) * (S->y1 - a.y) - (b.y - a.y) * (S->x1 - a.x);
      if ((d3 > 0) != (d4 > 0)) return true;
    }
  }
  return false;
}

static void dijkstra(int goal) {
  memset(ndist, 0xFF, sizeof ndist);
  nheap = 0;
  ndist[goal] = 0;
  hpush(goal);
  bool doors = false;
  for (int d = 0; d < N_DOORS; d++) doors |= door_closed(d);
  static const int8_t DX[8] = {1, -1, 0, 0, 1, 1, -1, -1}, DY[8] = {0, 0, 1, -1, 1, -1, 1, -1};
  while (nheap) {
    int c = hpop();
    int x = c % NAV_W, y = c / NAV_W;
    for (int k = 0; k < 8; k++) {
      int nx = x + DX[k], ny = y + DY[k];
      if (!nav_ok(nx, ny)) continue;
      if (k >= 4 && (!nav_ok(nx, y) || !nav_ok(x, ny))) continue;
      int n = ny * NAV_W + nx;
      uint16_t nd = (uint16_t)(ndist[c] + (k >= 4 ? 14 : 10));
      if (nd >= ndist[n]) continue;
      if (doors && door_blocks(cell_pos(c), cell_pos(n))) continue;
      ndist[n] = nd;
      hpush(n);
    }
  }
}

/* is the straight line from a to b walkable (every point on it in a walkable cell, no wall across) */
static bool straight(V2 a, V2 b) {
  float dx = b.x - a.x, dy = b.y - a.y, l = sqrtf(dx * dx + dy * dy);
  int n = (int)(l / 0.2f) + 1;
  for (int k = 1; k < n; k++) {
    float t = (float)k / n;
    int x = (int)floorf((a.x + dx * t - NAV_X0) / NAV_CS), y = (int)floorf((a.y + dy * t - NAV_Y0) / NAV_CS);
    if (!nav_ok(x, y)) return false;
  }
  return !ship_wall_between(a, b) && !door_blocks(a, b);
}

/* a path for bot i to goal (straight lines between corners of the grid's way) */
static bool plan(int i, V2 goal) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;
  B->goal = goal;
  B->plen = B->pi = 0;
  if (!P->alive) return true;   /* (ghosts fly straight) */
  int from = nearest_cell(P->pos), to = nearest_cell(goal);
  if (from < 0 || to < 0) return false;
  dijkstra(to);
  if (ndist[from] == 0xFFFF) return false;
  /* down the distances, keeping only the cells a straight walk can't skip */
  uint16_t cells[160];
  int n = 0, c = from;
  cells[n++] = (uint16_t)c;
  static const int8_t DX[8] = {1, -1, 0, 0, 1, 1, -1, -1}, DY[8] = {0, 0, 1, -1, 1, -1, 1, -1};
  while (c != to && n < 160) {
    int x = c % NAV_W, y = c / NAV_W, best = -1;
    for (int k = 0; k < 8; k++) {
      int nx = x + DX[k], ny = y + DY[k];
      if (!nav_ok(nx, ny)) continue;
      int m = ny * NAV_W + nx;
      if (ndist[m] < ndist[c] && (best < 0 || ndist[m] < ndist[best])) best = m;
    }
    if (best < 0) break;
    c = best;
    cells[n++] = (uint16_t)c;
  }
  V2 at = P->pos;
  int k = 0;
  while (k < n - 1 && B->plen < 40) {
    int far = k + 1;
    for (int j = n - 1; j > k + 1; j--)
      if (straight(at, cell_pos(cells[j]))) {
        far = j;
        break;
      }
    B->path[B->plen++] = cells[far];
    at = cell_pos(cells[far]);
    k = far;
  }
  return true;
}

#ifdef HOST
/* (tests) is p walled in: no walkable cell within 1.5 units that a straight line reaches */
bool bot_enclosed(V2 p) {
  int cx = (int)floorf((p.x - NAV_X0) / NAV_CS), cy = (int)floorf((p.y - NAV_Y0) / NAV_CS);
  for (int y = cy - 3; y <= cy + 3; y++)
    for (int x = cx - 3; x <= cx + 3; x++)
      if (nav_ok(x, y) && !ship_wall_between(p, cell_pos(y * NAV_W + x))) return false;
  return true;
}
#endif

/* ---- perception ---- */

static float dist2(V2 a, V2 b) { return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y); }

/* The four fixed Security cameras cover small rectangular views on the Skeld.
   Comms sabotage disables both their observation and their deterrent effect. */
static bool camera_covers(int k, V2 p) {
  if (k < 0 || k >= N_CAMS || g.sab == SAB_COMMS) return false;
  float dx = fabsf(p.x - CAMS[k].x), dy = fabsf(p.y - CAMS[k].y);
  return dx <= CAMS[k].size * 2.05f && dy <= CAMS[k].size * 1.02f &&
         !ship_wall_between((V2){CAMS[k].x, CAMS[k].y}, p);
}
static bool any_camera_covers(V2 p) {
  for (int k = 0; k < N_CAMS; k++) if (camera_covers(k, p)) return true;
  return false;
}

/* would anyone (but the impostors and the victim) see a kill at p */
static bool witnessed(int imp, int victim, V2 p) {
  if (any_camera_covers(p)) return true;
  for (int j = 0; j < g.nplayers; j++) {
    const Player *Q = &g.p[j];
    if (j == imp || j == victim || !Q->alive || Q->imp || Q->vent != NONE) continue;
    float r = vision_radius(j) + 0.5f;
    if (dist2(Q->pos, p) < r * r && !ship_light_between(Q->pos, p)) return true;
  }
  return false;
}

static void suspect(Bot *B, int who, int by) {
  int v = B->sus[who] + by;
  B->sus[who] = (int8_t)(v > 100 ? 100 : v < -100 ? -100 : v);
}

static void queue_reply(int who, int kind, int a, int b, float at);
static bool is_accusation_line(int kind);
static void conversation_reaction(int speaker, int kind, int a, int b);

/* Bots consider the player's quick-chat statements during meetings. */
void bot_hear_player(int kind, int target, int room) {
  /* Every message is remembered by every living bot, including messages that
     do not name a player. A claim is still not treated as automatic truth. */
  int weight = 5;
  switch (kind) {
  case L_PLAYER_KILL: case L_PLAYER_VENT: weight = 30; break;
  case L_PLAYER_SUS: case L_PLAYER_NOT_TRUST: case L_PLAYER_LYING: weight = 14; break;
  case L_PLAYER_SAFE: case L_PLAYER_TRUST: case L_PLAYER_ALIBI: weight = -12; break;
  case L_PLAYER_WITH: case L_PLAYER_IN_ROOM: case L_PLAYER_SEEN_ROOM:
  case L_PLAYER_SEEN_IN_ROOM: case L_PLAYER_LAST_IN_ROOM: case L_PLAYER_FOLLOW:
  case L_PLAYER_LAST: weight = 7; break;
  case L_PLAYER_CONFIRM: weight = -8; break;
  case L_SCANNED: weight = -14; break;
  case L_PLAYER_NO_CONFIRM: weight = 8; break;
  default: weight = 0; break;
  }
  if (g.opt.difficulty == 0) weight = weight * 2 / 3;
  else if (g.opt.difficulty == 2) weight = weight / 2;
  else if (g.opt.difficulty >= 3) weight = weight * 2 / 3;

  for (int i = 0; i < g.nplayers; i++) {
    if (!is_bot(i) || !g.p[i].alive) continue;
    Bot *B = &g.p[i].bot;
    if (B->heard_claims[g.me] < 255) B->heard_claims[g.me]++;
    B->last_claim_kind[g.me] = (uint8_t)kind;
    B->last_claim_target[g.me] = (uint8_t)(target >= 0 && target < g.nplayers ? target : NONE);
    B->last_claim_room[g.me] = (uint8_t)(room >= 0 && room < N_ROOMS ? room : NONE);

    if (target >= 0 && target < g.nplayers && target != i && !g.p[i].imp && weight) {
      int trust = B->credibility[g.me] < 20 ? 0 : B->credibility[g.me] > 75 ? 2 : 1;
      suspect(B, target, weight * trust);
    }

    /* Reward a confirmation only when this bot independently remembers the
       named player in the named room. Contradictions reduce confidence instead. */
    if (kind == L_PLAYER_CONFIRM && target >= 0 && target < g.nplayers &&
        room >= 0 && room < N_ROOMS && target != i) {
      float age = g.t - B->seen_t[target];
      if (B->seen_t[target] > 0 && age >= 0 && age < 35 && B->seen_room[target] < N_ROOMS) {
        if (B->seen_room[target] == room) {
          if (B->relation[g.me] < 60) B->relation[g.me] =
              (int8_t)(B->relation[g.me] > 58 ? 60 : B->relation[g.me] + 2);
          if (B->credibility[g.me] < 95) B->credibility[g.me] += 5;
          if (B->sus[target] > -75) suspect(B, target, -8);
        } else {
          if (B->relation[g.me] > -60) B->relation[g.me] =
              (int8_t)(B->relation[g.me] < -58 ? -60 : B->relation[g.me] - 2);
          if (B->credibility[g.me] > -95) B->credibility[g.me] -= 6;
          if (g.p[g.me].imp && B->false_claims[g.me] < 255) B->false_claims[g.me]++;
          suspect(B, g.me, 10);
        }
      }
    }
  }

  /* A direct accusation should not disappear into the void: the accused bot
     can answer, and a teammate may defend them without a guaranteed chorus. */
  if (target >= 0 && target < g.nplayers && g.p[target].alive &&
      (kind == L_PLAYER_SUS || kind == L_PLAYER_NOT_TRUST || kind == L_PLAYER_LYING ||
       kind == L_PLAYER_VENT || kind == L_PLAYER_KILL)) {
    if (is_bot(target) && rnd_n(100) < (g.opt.difficulty >= 3 ? 100 : g.opt.difficulty == 2 ? 98 : g.opt.difficulty == 1 ? 96 : 93))
      queue_reply(target, L_NOT_ME, 0, 0, g.meet_t + 0.8f + rnd_f() * 1.0f);
    if (g.p[target].imp) {
      int defender = -1;
      for (int j = 0; j < g.nplayers; j++)
        if (j != target && is_bot(j) && g.p[j].alive && g.p[j].imp) { defender = j; break; }
      if (defender >= 0 && rnd_n(100) < 65)
        queue_reply(defender, L_PLAYER_DISAGREE, g.me, 0, g.meet_t + 1.4f + rnd_f() * 1.4f);
    }
  }
  conversation_reaction(g.me, kind, target, room);
}

/* what bot i sees now */
void bot_see(int i) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;
  if (!P->alive) return;
  for (int j = 0; j < g.nplayers; j++) {
    if (j == i) continue;
    Player *Q = &g.p[j];
    bool seen = Q->alive && can_see(i, j);
    if (seen) {
      B->seen_t[j] = g.t;
      B->seen_room[j] = Q->room;
      /* and who was with them */
      int with = NONE;
      float wd = 2.2f * 2.2f;
      for (int k = 0; k < g.nplayers; k++)
        if (k != j && k != i && g.p[k].alive && g.p[k].vent == NONE && dist2(g.p[k].pos, Q->pos) < wd && can_see(i, k))
          wd = dist2(g.p[k].pos, Q->pos), with = k;
      B->seen_with[j] = (uint8_t)with;
      B->with_t[j] += 0.2f;
      if (B->with_t[j] > 60) B->with_t[j] = 60;
      /* a visual task proves a crewmate */
      if (g.opt.visual && Q->busy && !Q->imp && (Q->bot.task < MAX_TASKS) &&
          TASK_DEFS[Q->tasks[Q->bot.task].def].type == T_SUBMIT_SCAN)
        B->sus[j] = -100, B->scanned = (uint8_t)j;
      if (Q->vent_anim) {
        B->saw_vent = (uint8_t)j, B->saw_vent_room = Q->room;
        suspect(B, j, 100);
      }
    } else if (B->with_t[j] > 0) B->with_t[j] -= 0.05f;
  }
  if (P->imp) return;
  /* bodies */
  for (int b = 0; b < MAXP; b++) {
    const Body *D = &g.bodies[b];
    if (!D->on) continue;
    float r = vision_radius(i);
    if (dist2(P->pos, D->pos) > r * r || ship_light_between(P->pos, D->pos)) continue;
    if (B->state == B_REPORT && B->found_body == b) continue;
    B->found_body = (uint8_t)b;
    B->body_room = (uint8_t)ship_room_at(D->pos);
    /* Who was near it? In a stack, several players overlap the body, so the
       nearest sprite is not enough to identify the killer. */
    B->near_body = NONE;
    float bd = 4.0f * 4.0f;
    int pile = 0;
    for (int j = 0; j < g.nplayers; j++) {
      if (j == i || !g.p[j].alive || g.p[j].vent != NONE) continue;
      float d = dist2(g.p[j].pos, D->pos);
      if (d < 1.65f * 1.65f) pile++;
      if (d < bd && can_see(i, j)) bd = d, B->near_body = (uint8_t)j;
    }
    /* Being merely visible in the same room is not evidence. A player almost
       on top of a non-stack body is a lead, but still weaker than a witnessed kill. */
    if (pile < 3 && B->near_body != NONE && bd < 1.55f * 1.55f) suspect(B, B->near_body, 14);
    else if (pile >= 3) B->near_body = NONE;
    B->state = B_REPORT;
    B->target = (uint8_t)b;
    plan(i, D->pos);
  }
}

/* Admin gives anonymous room counts; cameras give actual sightings from their fixed views.
   Neither system grants the bot knowledge of a player's role. */
static void admin_observe(Bot *B) {
  uint8_t counts[N_ROOMS] = {0};
  for (int j = 0; j < g.nplayers; j++)
    if (g.p[j].alive && g.p[j].vent == NONE && g.p[j].room < N_ROOMS && counts[g.p[j].room] < 255)
      counts[g.p[j].room]++;
  for (int b = 0; b < MAXP; b++)
    if (g.bodies[b].on) {
      int room = ship_room_at(g.bodies[b].pos);
      if (room >= 0 && room < N_ROOMS && counts[room] < 255) counts[room]++;
    }
  int focus = -1, most = 1;
  for (int r = 1; r < N_ROOMS; r++) if (counts[r] > most) most = counts[r], focus = r;
  memcpy(B->admin_counts, counts, sizeof counts);
  B->admin_valid = 1;
  B->admin_focus_room = (uint8_t)(focus < 0 ? NONE : focus);
}

static bool camera_observe(int i) {
  Bot *B = &g.p[i].bot;
  for (int b = 0; b < MAXP; b++) {
    const Body *D = &g.bodies[b];
    if (!D->on) continue;
    for (int c = 0; c < N_CAMS; c++) if (camera_covers(c, D->pos)) {
      B->found_body = (uint8_t)b;
      B->body_room = (uint8_t)ship_room_at(D->pos);
      B->near_body = NONE;
      return true;
    }
  }
  for (int j = 0; j < g.nplayers; j++) {
    if (j == i) continue;
    const Player *Q = &g.p[j];
    if (!Q->alive || Q->vent != NONE) continue;
    int visible = 0;
    for (int c = 0; c < N_CAMS; c++) visible |= camera_covers(c, Q->pos);
    if (!visible) continue;
    B->seen_t[j] = g.t;
    B->seen_room[j] = Q->room;
    int with = NONE; float wd = 2.2f * 2.2f;
    for (int k = 0; k < g.nplayers; k++) {
      if (k == j || k == i || !g.p[k].alive || g.p[k].vent != NONE) continue;
      if (dist2(g.p[k].pos, Q->pos) < wd) with = k, wd = dist2(g.p[k].pos, Q->pos);
    }
    B->seen_with[j] = (uint8_t)with;
    if (with != NONE) { B->with_t[j] += 0.8f; if (B->with_t[j] > 60) B->with_t[j] = 60; }
    if (Q->vent_anim) {
      B->saw_vent = (uint8_t)j;
      B->saw_vent_room = Q->room;
      suspect(B, j, 100);
    }
  }
  return false;
}

static int console_of_kind(int kind) {
  for (int c = 0; c < N_CONSOLES; c++) if (CONSOLES[c].kind == kind) return c;
  return -1;
}

static void surveillance_tick(int i) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;
  B->intel_t -= DT;
  if (B->intel_t <= 0) {
    B->intel_t = 0.8f;
    if (B->target == G_ADMIN) admin_observe(B);
    else if (B->target == G_CAMS && camera_observe(i)) {
      B->target = B->found_body;
      B->state = B_REPORT;
      plan(i, g.bodies[B->target].pos);
      return;
    }
  }
  B->t -= DT;
  if (B->t <= 0) {
    B->state = B_WAIT;
    B->t = 0.5f + rnd_f();
    B->intel_cd = (g.opt.difficulty >= 3 ? 28.0f : 42.0f) + rnd_f() * 22.0f;
    /* After checking Admin, a crewmate may head toward the busiest room.
       Counts remain anonymous: it never invents a player's identity. */
    if (B->target == G_ADMIN && B->admin_valid && B->admin_focus_room < N_ROOMS && rnd_n(2) == 0) {
      int best = -1; float bd = 1e9f;
      for (int c = 0; c < N_CONSOLES; c++) if (!CONSOLES[c].kind && CONSOLES[c].room == B->admin_focus_room) {
        float d = dist2(P->pos, stand(c));
        if (d < bd) bd = d, best = c;
      }
      if (best >= 0) go(i, stand(best), G_WANDER, best);
    }
  }
}

/* a kill seen as it happens (kill_player asks each living bot) */
void bot_saw_kill(int i, int killer) {
  Bot *B = &g.p[i].bot;
  if (g.p[i].imp) return;
  if (can_see(i, killer)) {
    B->saw_kill = (uint8_t)killer;
    B->saw_kill_room = g.p[killer].room;
    suspect(B, killer, 100);
  }
}

/* ---- deciding ---- */

/* how many crewmates (but j) are near player j */
static int company(int j) {
  int n = 0;
  for (int k = 0; k < g.nplayers; k++)
    if (k != j && g.p[k].alive && !g.p[k].imp && g.p[k].vent == NONE && dist2(g.p[k].pos, g.p[j].pos) < 4.5f * 4.5f) n++;
  return n;
}

/* an impostor goes after the crewmate most alone (and nearest): false if nobody is worth it */
static bool start_hunt(int i) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;
  int best = -1;
  float bs = -1e9f;
  for (int j = 0; j < g.nplayers; j++) {
    const Player *Q = &g.p[j];
    if (!Q->alive || Q->imp || Q->vent != NONE) continue;
    int nearby = company(j);
    float distance = sqrtf(dist2(P->pos, Q->pos));
    /* Do not lock onto a distant player and trail them across the map. */
    if (nearby >= 2 || distance > 9.0f) continue;
    if (g.opt.difficulty >= 2 && any_camera_covers(Q->pos)) continue;
    float s = -nearby * 13 - distance * 1.0f + rnd_f() * (g.opt.difficulty >= 3 ? 6.0f : 9.0f);
    if (g.opt.difficulty >= 3 && Q->room == P->room) s += 2.5f;
    if (s > bs) bs = s, best = j;
  }
  if (best < 0 || bs < -30) return false;
  B->state = B_HUNT;
  B->task = (uint8_t)best;
  B->hunt_t = 0;
  B->t = 0;
  B->stuck_t = 0;
  return true;
}

static float task_time(const Task *t) {
  switch (TASK_DEFS[t->def].type) {
  case T_SWIPE_CARD: return 3.5f;
  case T_FIX_WIRING: return 4;
  case T_CLEAR_ASTEROIDS: return 16;
  case T_ALIGN_ENGINE: return 3;
  case T_SUBMIT_SCAN: return 10;
  case T_INSPECT_SAMPLE: return 2.5f;
  case T_FUEL_ENGINES: return 3.5f;
  case T_START_REACTOR: return 14;
  case T_EMPTY_CHUTE:
  case T_EMPTY_GARBAGE: return 3.5f;
  case T_UPLOAD_DATA: return 9;
  case T_CALIBRATE: return 6;
  case T_CHART_COURSE: return 4;
  case T_CLEAN_O2: return 6;
  case T_UNLOCK_MANIFOLDS: return 6;
  case T_STABILIZE: return 2.5f;
  case T_PRIME_SHIELDS: return 3;
  case T_DIVERT_POWER: return t->step ? 1.5f : 3;
  default: return 3;
  }
}

static void go(int i, V2 to, int why, int cons) {
  Bot *B = &g.p[i].bot;
  if (!plan(i, to)) {
    B->state = B_WAIT;
    B->t = 1 + rnd_f();
    return;
  }
  B->state = B_WALK;
  B->target = (uint8_t)why;
  B->cons = (uint8_t)cons;
  B->stuck_t = 0;
  B->last = g.p[i].pos;
}

static V2 stand(int c) { return (V2){CONSOLES[c].sx, CONSOLES[c].sy}; }

/* the nearest console of an unfinished task step; its task in *task */
static int next_task(int i, int *task) {
  Player *P = &g.p[i];
  int best = -1;
  float bd = 1e9f;
  for (int k = 0; k < P->ntasks; k++) {
    Task *t = &P->tasks[k];
    if (task_done(t) || t->timer > 0) continue;
    for (int c = 0; c < N_CONSOLES; c++) {
      if (!console_serves(c, t)) continue;
      float d = dist2(P->pos, stand(c));
      if (d < bd) bd = d, best = c, *task = k;
    }
  }
  return best;
}

/* the consoles that fix the sabotage and still need someone (reactor and oxygen have two) */
static int fix_consoles(int *out) {
  static const uint8_t FIX[] = {0, T_RESET_REACTOR, T_RESTORE_O2, T_FIX_LIGHTS, T_FIX_COMMS};
  int n = 0;
  for (int c = 0; c < N_CONSOLES && n < 4; c++) {
    const ConsoleRec *C = &CONSOLES[c];
    if (C->kind || !(C->types >> FIX[g.sab] & 1)) continue;
    if (g.sab == SAB_O2 && (g.o2_done >> (C->room == R_ADMIN ? 0 : 1) & 1)) continue;
    out[n++] = c;
  }
  return n;
}

static bool fixing(int j, int c) {
  const Bot *B = &g.p[j].bot;
  return (B->state == B_FIX || (B->state == B_WALK && B->target == G_FIX)) && B->cons == c;
}

/* a sabotage: the nearest free crewmate goes to each console that needs someone (after a moment to notice it) */
void bots_dispatch(void) {
  if (!g.sab || g.sab_age < 1.5f || (int)(g.t * 30) % 10) return;
  int cons[4], n = fix_consoles(cons);
  for (int k = 0; k < n; k++) {
    int c = cons[k];
    bool covered = false;
    for (int j = 0; j < g.nplayers; j++) covered |= is_bot(j) && g.p[j].alive && !g.p[j].imp && fixing(j, c);
    if (covered) continue;
    int best = -1;
    float bd = 1e9f;
    for (int j = 0; j < g.nplayers; j++) {
      const Player *Q = &g.p[j];
      if (!is_bot(j) || !Q->alive || Q->imp || Q->vent != NONE || Q->bot.state == B_REPORT) continue;
      bool busy = false;
      for (int m = 0; m < n; m++) busy |= fixing(j, cons[m]);
      if (busy) continue;
      float d = dist2(Q->pos, stand(c));
      /* (lights and comms can wait for a task to be done) */
      if (Q->bot.state == B_TASK && (g.sab == SAB_LIGHTS || g.sab == SAB_COMMS)) d += 200;
      if (d < bd) bd = d, best = j;
    }
    if (best < 0) continue;
    g.p[best].busy = 0;
    go(best, stand(cons[k]), G_FIX, cons[k]);
  }
}

static void wander(int i) {
  Bot *B = &g.p[i].bot;
  if (!g.p[i].imp && B->intel_cd <= 0 && rnd_n(g.opt.difficulty >= 3 ? 3 : g.opt.difficulty >= 2 ? 4 : 6) == 0) {
    int admin = console_of_kind(1), cams = console_of_kind(3);
    int c = (B->personality == 0 || B->personality == 1 || rnd_n(2) == 0) ? cams : admin;
    if (c < 0) c = c == cams ? admin : cams;
    if (c >= 0) { B->intel_cd = 65.0f; go(i, stand(c), c == admin ? G_ADMIN : G_CAMS, c); return; }
  }
  /* Followers and leaders sometimes regroup with a player they have actually seen;
     the goal is a nearby point, not the other player's exact position. */
  if ((B->personality == 3 || B->personality == 4) && rnd_n(3) == 0) {
    int candidates[MAXP], n = 0;
    for (int j = 0; j < g.nplayers; j++)
      if (j != i && g.p[j].alive && g.p[j].vent == NONE && g.t - B->seen_t[j] < 12.0f &&
          dist2(g.p[i].pos, g.p[j].pos) < 12.0f * 12.0f) candidates[n++] = j;
    if (n) {
      int j = candidates[rnd_n(n)];
      V2 q = g.p[j].pos;
      q.x += (rnd_f() - 0.5f) * 2.2f; q.y += (rnd_f() - 0.5f) * 2.2f;
      go(i, q, G_WANDER, 0);
      return;
    }
  }
  /* otherwise choose a console as a believable destination */
  int c = rnd_n(N_CONSOLES);
  go(i, stand(c), G_WANDER, c);
}

static void decide(int i) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;
  if (!P->imp) {
    int t = -1, c = next_task(i, &t);
    if (c >= 0) {
      go(i, stand(c), G_TASK, c);
      B->task = (uint8_t)t;
      return;
    }
    /* all done (or waiting on a sample): call a meeting on a strong suspicion, else walk around */
    if (P->alive && P->emergencies && g.emergency_cd <= 0 && !g.sab) {
      for (int j = 0; j < g.nplayers; j++)
        if (g.p[j].alive && B->sus[j] >= 80 && rnd_n(3) == 0) {
          go(i, stand(N_CONSOLES - 1 >= 0 ? 0 : 0), G_BUTTON, 0);
          for (int c2 = 0; c2 < N_CONSOLES; c2++)
            if (CONSOLES[c2].kind == 2) go(i, stand(c2), G_BUTTON, c2);
          return;
        }
    }
    wander(i);
    return;
  }
  /* an impostor */
  if (!P->alive) {
    if (sabotage_ready() && rnd_n(4) == 0) sabotage(SAB_LIGHTS + rnd_n(2));
    wander(i);
    return;
  }
  if (P->kill_cd < 5 && start_hunt(i)) return;
  /* a task to fake: the console of one of its (fake) tasks, or any */
  int t = -1, c = next_task(i, &t);
  if (c < 0 || rnd_n(3) == 0 ||
      (t >= 0 && g.opt.visual && TASK_DEFS[P->tasks[t].def].type == T_SUBMIT_SCAN)) {
    c = rnd_n(N_CONSOLES);
    t = -1;
  }
  B->task = (uint8_t)(t < 0 ? NONE : t);
  go(i, stand(c), G_FAKE, c);
}

/* ---- each tick ---- */

static void follow(int i) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;
  V2 to = B->pi < B->plen ? cell_pos(B->path[B->pi]) : B->goal;
  if (!P->alive) to = B->goal;
  float dx = to.x - P->pos.x, dy = to.y - P->pos.y, d = sqrtf(dx * dx + dy * dy);
  float step = player_speed(i) * DT;
  if (d < step * 1.5f) {
    if (P->alive && B->pi < B->plen) {
      B->pi++;
      walk(i, (V2){dx, dy});
      return;
    }
    /* there */
    walk(i, (V2){0, 0});
    P->pos = ship_move(P->pos, (V2){to.x - P->pos.x, to.y - P->pos.y}, PLAYER_R);
    B->state = B_IDLE;
    B->plen = 0;
    return;
  }
  walk(i, (V2){dx, dy});
  /* stuck against something: plan again */
  B->stuck_t += DT;
  if (B->stuck_t > 1.0f) {
    if (dist2(P->pos, B->last) < 0.3f * 0.3f) {
      if (!plan(i, B->goal)) B->state = B_IDLE;
    }
    B->stuck_t = 0;
    B->last = P->pos;
  }
}

static void arrive(int i) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;
  int why = B->target;
  switch (why) {
  case G_TASK: {
    Task *t = &P->tasks[B->task];
    if (!console_serves(B->cons, t)) {
      B->state = B_IDLE;
      return;
    }
    B->state = B_TASK;
    B->t = task_time(t) * (0.9f + 0.6f * rnd_f());
    P->busy = 1;
    return;
  }
  case G_FAKE: {
    float duration = B->task < MAX_TASKS ? task_time(&P->tasks[B->task]) : 2.5f + rnd_f() * 5.0f;
    B->state = B_TASK;
    B->task = NONE; /* impostors never complete the real task */
    B->t = duration * (0.9f + 0.35f * rnd_f());
    return;
  }
  case G_FIX:
    if (!g.sab) {
      B->state = B_IDLE;
      return;
    }
    B->state = B_FIX;
    B->t = g.sab == SAB_REACTOR ? 99 : g.sab == SAB_O2 ? 4 + rnd_f() * 2 : g.sab == SAB_LIGHTS ? 3 + rnd_f() * 2
                                                                                            : 4 + rnd_f() * 3;
    return;
  case G_BUTTON:
    if (P->alive && P->emergencies && g.emergency_cd <= 0 && !g.sab && g.screen == S_PLAY) {
      start_meeting(i, NONE);
      return;
    }
    B->state = B_IDLE;
    return;
  case G_ADMIN: case G_CAMS:
    B->state = B_SURVEIL;
    B->t = (g.opt.difficulty >= 3 ? 4.5f : 3.5f) + rnd_f() * 2.5f;
    B->intel_t = 0;
    P->busy = 0;
    return;
  case G_WANDER:
    B->state = B_WAIT;
    B->t = 1 + rnd_f() * 4;
    return;
  default:
    B->state = B_IDLE;
    return;
  }
}

static void impostor_tick(int i) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;

  /* kill whoever is in reach when nobody would see */
  if (P->kill_cd <= 0 && P->vent == NONE) {
    int t = kill_target(i);
    /* Stack kills should not always select the same nearest player. In a dense
       pile, choose among the crew actually inside kill range. */
    if (t >= 0) {
      int pile[MAXP], npile = 0;
      for (int j = 0; j < g.nplayers; j++) {
        Player *Q = &g.p[j];
        if (j == i || !Q->alive || Q->imp || Q->vent != NONE) continue;
        float dx = Q->pos.x - P->pos.x, dy = Q->pos.y - P->pos.y;
        float r = kill_distance();
        if (dx * dx + dy * dy <= r * r && !ship_wall_between(P->pos, Q->pos)) pile[npile++] = j;
      }
      if (npile >= 3) t = pile[rnd_n(npile)];
    }
    if (t >= 0 && !witnessed(i, t, g.p[t].pos) && !witnessed(i, t, P->pos) && rnd_n(4) == 0) {
      kill_player(i, t);
      /* away from the body: a vent close by, else somewhere else */
      int v = nearest_vent(P->pos, 3.5f);
      if (v >= 0 && rnd_n(3)) {
        go(i, (V2){VENTS[v].sx, VENTS[v].sy}, G_VENT, v);
      } else if (rnd_n(8) == 0 && g.screen == S_PLAY) {
        start_meeting(i, t);   /* a self report */
      } else
        wander(i);
      return;
    }
  }
  /* the kill nearly ready: off to find someone */
  if (P->kill_cd < (g.opt.difficulty >= 2 ? 8 : 4) && P->vent == NONE && rnd_n(g.opt.difficulty >= 3 ? 3 : g.opt.difficulty >= 2 ? 5 : 15) == 0 &&
      (B->state == B_TASK || B->state == B_WAIT || B->state == B_IDLE ||
       (B->state == B_WALK && (B->target == G_FAKE || B->target == G_WANDER))))
    start_hunt(i);
  /* Hard impostors use the ship itself to set up an ambush: when stalking an
   * isolated target, close that room's doors before committing to the chase. */
  if (g.opt.difficulty >= 2 && B->state == B_HUNT && B->task < g.nplayers &&
      g.p[B->task].alive && company(B->task) == 0 && P->kill_cd < 7 &&
      rnd_n(g.opt.difficulty >= 3 ? 30 * 3 : 30 * 5) == 0) {
    int room = g.p[B->task].room;
    if (room != R_HALLWAY) close_doors(room);
  }
  /* sabotage now and then, and the lights when about to kill */
  if (sabotage_ready() && P->alive) {
    if (P->kill_cd < 3 && B->state == B_HUNT && company(B->task) && rnd_n(30 * 4) == 0) sabotage(SAB_LIGHTS);
    else if (rnd_n(g.opt.difficulty >= 3 ? 30 * 24 : 30 * 35) == 0) {
      float progress = tasks_progress();
      int crew = living(false);
      int choice;
      if (B->state == B_HUNT && B->task < g.nplayers && company(B->task) > 0)
        choice = SAB_LIGHTS; /* obscure a crowded approach */
      else if (progress > 0.68f)
        choice = SAB_COMMS; /* delay a nearly completed task bar */
      else if (crew >= 7 && rnd_n(2) == 0)
        choice = rnd_n(2) ? SAB_REACTOR : SAB_O2; /* force a split response */
      else
        choice = rnd_n(3) == 0 ? SAB_LIGHTS : rnd_n(2) ? SAB_REACTOR : SAB_O2;
      sabotage(choice);
    }
  }
  if (rnd_n(g.opt.difficulty >= 3 ? 30 * 12 : g.opt.difficulty >= 2 ? 30 * 16 : 30 * 40) == 0) {
    static const uint8_t DR[] = {R_CAFETERIA, R_STORAGE, R_ELECTRICAL, R_MEDBAY, R_SECURITY, R_UPPER_ENGINE,
                                 R_LOWER_ENGINE};
    int r = B->state == B_HUNT ? g.p[B->task].room : DR[rnd_n(7)];
    for (unsigned k = 0; k < sizeof DR; k++)
      if (DR[k] == r) close_doors(r);
  }
}

void bot_init(int i) {
  Bot *B = &g.p[i].bot;
  memset(B, 0, sizeof *B);
  memset(B->seen_with, NONE, sizeof B->seen_with);
  B->state = B_WAIT;
  B->t = 0.5f + rnd_f() * 1.5f;
  B->saw_kill = B->saw_vent = B->near_body = B->found_body = NONE;
  B->task = NONE;
  B->with = NONE;
  B->scanned = NONE;
  B->personality = (uint8_t)rnd_n(6);
  B->memory_decay_t = 18.0f + rnd_f() * 12.0f;
  for (int j = 0; j < MAXP; j++) B->credibility[j] = 50;
  B->think = rnd_f() * 0.2f;
  B->admin_focus_room = NONE;
  B->intel_cd = 20.0f + rnd_f() * 30.0f;
}

void bot_tick(int i) {
  Player *P = &g.p[i];
  Bot *B = &P->bot;
  if (P->vent_anim) {
    walk(i, (V2){0, 0});
    return;
  }
  if (B->intel_cd > 0) B->intel_cd -= DT;
  /* Old, weak suspicions fade slowly; direct witnessed evidence remains durable. */
  B->memory_decay_t -= DT;
  if (B->memory_decay_t <= 0) {
    B->memory_decay_t = 18.0f + rnd_f() * 12.0f;
    for (int j = 0; j < g.nplayers; j++) if (j != i && fabsf((float)B->sus[j]) < 75) {
      if (B->sus[j] > 0) B->sus[j]--; else if (B->sus[j] < 0) B->sus[j]++;
    }
  }
  /* look around five times a second */
  B->think -= DT;
  if (B->think <= 0) {
    B->think += g.opt.difficulty == 0 ? 0.35f : g.opt.difficulty >= 3 ? 0.065f : g.opt.difficulty == 2 ? 0.10f : 0.2f;
    bot_see(i);
    if (g.screen != S_PLAY) return;
  }
  if (P->imp && P->alive) {
    impostor_tick(i);
    if (g.screen != S_PLAY) return;
  }
  if (P->imp && P->alive && g.sab && rnd_n(400) == 0 && B->state != B_HUNT && B->state != B_VENT) {
    /* to the sabotage, as if to fix it */
    int cons[4], n = fix_consoles(cons);
    if (n) go(i, stand(cons[rnd_n(n)]), G_FAKE, cons[0]);
  }
  switch (B->state) {
  case B_IDLE:
    walk(i, (V2){0, 0});
    P->busy = 0;
    decide(i);
    break;
  case B_WAIT:
    walk(i, (V2){0, 0});
    B->t -= DT;
    if (B->t <= 0) B->state = B_IDLE;
    break;
  case B_WALK:
    follow(i);
    if (B->state == B_IDLE) {
      if (B->target == G_VENT && P->imp && P->alive) {
        int v = B->cons;
        enter_vent(i, v);
        B->state = B_VENT;
        B->t = 1 + rnd_f() * 2;
        B->plen = (uint8_t)rnd_n(3);
      } else
        arrive(i);
    }
    break;
  case B_REPORT: {
    const Body *D = &g.bodies[B->target];
    if (!D->on) {
      B->state = B_IDLE;
      break;
    }
    if (dist2(P->pos, D->pos) < 2.5f * 2.5f && !ship_wall_between(P->pos, D->pos)) {
      walk(i, (V2){0, 0});
      start_meeting(i, D->who);
      return;
    }
    follow(i);
    if (B->state == B_IDLE) B->state = B_REPORT, plan(i, D->pos);
    break;
  }
  case B_SURVEIL:
    walk(i, (V2){0, 0});
    surveillance_tick(i);
    break;
  case B_TASK:
    walk(i, (V2){0, 0});
    B->t -= DT;
    if (B->t <= 0) {
      P->busy = 0;
      if (B->task < MAX_TASKS) {
        Task *t = &P->tasks[B->task];
        int type = TASK_DEFS[t->def].type;
        if (type == T_INSPECT_SAMPLE && t->timer < 0) t->timer = 60;
        else if (type == T_CLEAR_ASTEROIDS) {
          while (!task_done(t)) task_step_done(i, B->task);
        } else
          task_step_done(i, B->task);
      }
      B->state = B_WAIT;
      B->t = 0.4f + rnd_f() * 1.6f;
      /* now and then a look around before the next task */
      if (!P->imp && rnd_n(4) == 0) wander(i);
    }
    break;
  case B_FIX: {
    walk(i, (V2){0, 0});
    const ConsoleRec *C = &CONSOLES[B->cons];
    if (!g.sab) {
      B->state = B_IDLE;
      break;
    }
    if (g.sab == SAB_REACTOR) {
      g.reactor_hold[C->id & 1] = (uint8_t)i;
      break;
    }
    B->t -= DT;
    if (B->t <= 0) {
      if (g.sab == SAB_O2) g.o2_done |= (uint8_t)(C->room == R_ADMIN ? 1 : 2);
      else if (g.sab == SAB_LIGHTS) g.switches = 0x1F;
      else if (g.sab == SAB_COMMS) fix_sabotage();
      B->state = B_IDLE;
    }
    break;
  }
  case B_HUNT: {
    const Player *Q = &g.p[B->task];
    if (!Q->alive || P->kill_cd > 8) {
      B->state = B_IDLE;
      break;
    }
    /* in company for a while: someone else */
    B->hunt_t += DT;
    B->stuck_t = company(B->task) > 0 ? B->stuck_t + DT : 0;
    /* Do not visibly shadow a protected target or follow one across the map.
       Break contact, resume a believable route, and choose again later. */
    float target_distance = sqrtf(dist2(P->pos, Q->pos));
    bool target_noticed = target_distance > 2.8f && can_see(B->task, i);
    if (B->stuck_t > 0.65f || B->hunt_t > 3.8f ||
        (B->hunt_t > 1.6f && target_distance > 7.0f) || target_noticed) {
      B->state = B_IDLE;
      B->stuck_t = B->hunt_t = 0;
      B->t = 1.0f + rnd_f() * 2.0f;
      wander(i);
      break;
    }
    B->t -= DT;
    if (B->t <= 0 || B->pi >= B->plen) {
      B->t = 0.7f;
      if (!plan(i, Q->pos)) {
        B->state = B_IDLE;
        break;
      }
    }
    if (dist2(P->pos, Q->pos) < 0.8f * 0.8f) walk(i, (V2){0, 0});
    else {
      follow(i);
      if (B->state == B_IDLE) B->state = B_HUNT;
    }
    break;
  }
  case B_VENT:
    walk(i, (V2){0, 0});
    B->t -= DT;
    if (B->t <= 0 && P->vent != NONE) {
      if (B->plen) {
        /* to a linked vent */
        int links[3], n = 0;
        for (int k = 0; k < 3; k++)
          if (VENTS[P->vent].link[k] >= 0) links[n++] = VENTS[P->vent].link[k];
        if (n) move_vent(i, links[rnd_n(n)]);
        B->plen--;
        B->t = 0.6f + rnd_f();
      } else {
        /* out when nobody would see */
        if (!witnessed(i, NONE, P->pos) || B->t < -6) {
          exit_vent(i);
          B->state = B_WAIT;
          B->t = 0.6f;
        }
      }
    }
    break;
  default:
    B->state = B_IDLE;
  }
}

/* ---- meetings ---- */

static void say(int who, int kind, int a, int b) {
  if (g.nlines >= MAX_LINES) {
    memmove(g.lines, g.lines + 1, sizeof g.lines[0] * (MAX_LINES - 1));
    g.nlines--;
  }
  g.lines[g.nlines++] = (Line){(uint8_t)who, (uint8_t)kind, (uint8_t)a, (uint8_t)b};
}

/* each bot's lines for this meeting, said one after another in bot_meeting_tick */
static uint8_t queue_who[96], queue_kind[96], queue_a[96], queue_b[96];
static float queue_at[96];
static int nqueue, qnext;

static void queue(int who, int kind, int a, int b, float at) {
  if (nqueue >= 96) return;
  queue_who[nqueue] = (uint8_t)who, queue_kind[nqueue] = (uint8_t)kind, queue_a[nqueue] = (uint8_t)a;
  queue_b[nqueue] = (uint8_t)b, queue_at[nqueue] = at;
  nqueue++;
}

/* Insert follow-up replies in time order, without disturbing the unread queue. */
static void queue_reply(int who, int kind, int a, int b, float at) {
  if (nqueue >= 96) return;
  int pos = nqueue;
  while (pos > qnext && queue_at[pos - 1] > at) {
    queue_who[pos] = queue_who[pos - 1]; queue_kind[pos] = queue_kind[pos - 1];
    queue_a[pos] = queue_a[pos - 1]; queue_b[pos] = queue_b[pos - 1]; queue_at[pos] = queue_at[pos - 1];
    pos--;
  }
  queue_who[pos] = (uint8_t)who; queue_kind[pos] = (uint8_t)kind;
  queue_a[pos] = (uint8_t)a; queue_b[pos] = (uint8_t)b; queue_at[pos] = at;
  nqueue++;
}

/* The player can question bots too. Answers are scheduled into the same
   discussion queue as bot-to-bot replies, so they appear naturally in chat. */
void bot_player_question(int kind, int target, int room) {
  if (target < 0 || target >= g.nplayers || !g.p[target].alive) return;
  if (kind == L_ASK_WHERE) {
    int chance = g.opt.difficulty >= 3 ? 100 : g.opt.difficulty == 2 ? 99 : g.opt.difficulty == 1 ? 97 : 94;
    if (is_bot(target) && rnd_n(100) < chance)
      queue_reply(target, L_ANSWER_WHERE, g.p[target].room, g.me,
                  g.meet_t + 0.9f + rnd_f() * 1.0f);
  } else if (kind == L_ASK_CONFIRM && room >= 0 && room < N_ROOMS) {
    int best = -1; float freshest = 100000.0f;
    for (int j = 0; j < g.nplayers; j++) {
      if (j == g.me || j == target || !is_bot(j) || !g.p[j].alive || g.p[j].imp) continue;
      Bot *W = &g.p[j].bot;
      float age = g.t - W->seen_t[target];
      if (age >= 0 && age < 35 && W->seen_room[target] == room && age < freshest)
        best = j, freshest = age;
    }
    if (best >= 0) queue_reply(best, L_CONFIRM, target, room, g.meet_t + 0.9f + rnd_f() * 0.6f);
    else {
      /* A cautious witness can explicitly say that nobody has confirmed it. */
      int witness = -1;
      for (int j = 0; j < g.nplayers; j++)
        if (j != g.me && j != target && is_bot(j) && g.p[j].alive && !g.p[j].imp &&
            g.p[j].bot.personality == 0) { witness = j; break; }
      if (witness >= 0) queue_reply(witness, L_NO_CONFIRM, target, room, g.meet_t + 1.0f);
    }
  }
}

static int top_suspect(int i, int *score) {
  const Bot *B = &g.p[i].bot;
  int best = -1, bs = -1000;
  for (int j = 0; j < g.nplayers; j++) {
    if (j == i || !g.p[j].alive) continue;
    if (g.p[i].imp && g.p[j].imp) continue;
    if (B->sus[j] > bs) bs = B->sus[j], best = j;
  }
  *score = bs;
  return best;
}

void bot_meeting_start(void) {
  nqueue = qnext = 0;
  g.nlines = 0;
  g.line_shown = 0;
  float at = 1.5f;
  /* A last sighting in the same room is not an alibi contradiction or proof.
     Evidence is handled from close-range observations and recent timelines. */
  /* the caller first */
  int c = g.caller;
  if (is_bot(c)) {
    Bot *B = &g.p[c].bot;
    if (g.reported != NONE) {
      queue(c, L_BODY_IN, g.reported, g.p[c].imp ? g.p[c].room : B->body_room, at), at += 1.6f;
      if (!g.p[c].imp && B->saw_kill != NONE && g.p[B->saw_kill].alive)
        queue(c, L_SAW_KILL, B->saw_kill, B->saw_kill_room, at), at += 1.6f;
      else if (!g.p[c].imp && B->near_body != NONE && g.p[B->near_body].alive)
        queue(c, L_NEAR_BODY, B->near_body, B->body_room, at), at += 1.6f;
      else if (g.p[c].imp) {
        /* a lie: whoever it last saw */
        int best = -1;
        float bt = -1;
        for (int j = 0; j < g.nplayers; j++)
          if (j != c && g.p[j].alive && !g.p[j].imp && B->seen_t[j] > bt) bt = B->seen_t[j], best = j;
        if (best >= 0 && rnd_n(2)) queue(c, L_NEAR_BODY, best, g.p[c].room, at), at += 1.6f;
      }
    } else {
      int s, w = top_suspect(c, &s);
      if (w >= 0 && s >= 40) queue(c, B->saw_vent == w ? L_SAW_VENT : L_SUS, w, B->saw_vent_room, at), at += 1.6f;
      else queue(c, L_BUTTON, 0, 0, at), at += 1.6f;
    }
  }
  /* the others, in a random order */
  int order[MAXP], n = 0;
  for (int i = 0; i < g.nplayers; i++)
    if (is_bot(i) && i != c && g.p[i].alive) order[n++] = i;
  for (int k = n - 1; k > 0; k--) {
    int j = rnd_n(k + 1), t = order[k];
    order[k] = order[j], order[j] = t;
  }
  for (int k = 0; k < n; k++) {
    int i = order[k];
    Bot *B = &g.p[i].bot;
    at += 1.3f + rnd_f() * 1.1f;
    if (!g.p[i].imp && B->saw_kill != NONE && g.p[B->saw_kill].alive) {
      queue(i, L_SAW_KILL, B->saw_kill, B->saw_kill_room, at);
      continue;
    }
    if (!g.p[i].imp && B->saw_vent != NONE && g.p[B->saw_vent].alive) {
      queue(i, L_SAW_VENT, B->saw_vent, B->saw_vent_room, at);
      continue;
    }
    /* the one last seen with the dead */
    int v = g.reported;
    if (!g.p[i].imp && v != NONE && B->seen_with[v] != NONE && B->seen_with[v] != i && g.p[B->seen_with[v]].alive &&
        g.t - B->seen_t[v] < 7.0f) {
      /* Only a very recent sighting near the victim is worth mentioning;
         it remains a lead, never an automatic accusation. */
      suspect(B, B->seen_with[v], 5);
      queue(i, L_SAW_WITH, B->seen_with[v], B->seen_room[v], at);
      continue;
    }
    int r = rnd_n(10);
    if (B->personality == 4 && r < 3 && g.reported != NONE) {
      int score, suspect_id = top_suspect(i, &score);
      if (suspect_id >= 0 && score >= 25) { queue(i, L_SUS, suspect_id, B->seen_room[suspect_id], at); continue; }
    }
    if (B->personality == 5 && r < 5) { queue(i, L_PLAYER_NEED_INFO, 0, 0, at); continue; }
    if (!g.p[i].imp && B->scanned != NONE && g.p[B->scanned].alive && r < 3) {
      queue(i, L_SCANNED, B->scanned, 0, at);
      continue;
    }
    if (r < 2) {
      queue(i, g.reported != NONE ? L_WHERE : L_WHO, g.reported, 0, at);
      continue;
    }
    /* an alibi: where it was, with whom (impostors make one up) */
    int with = NONE;
    float wt = 8;
    for (int j = 0; j < g.nplayers; j++)
      if (j != i && g.p[j].alive && B->with_t[j] > wt) wt = B->with_t[j], with = j;
    int room = g.p[i].room;
    if (g.p[i].imp && rnd_n(2)) room = TASK_DEFS[g.p[i].tasks[rnd_n(g.p[i].ntasks)].def].room;
    if (with != NONE && !g.p[i].imp) queue(i, L_WITH, with, room, at);
    else queue(i, L_WAS_IN, room, 0, at);
    int s, w = top_suspect(i, &s);
    if (w >= 0 && (s >= 30 || (g.p[i].imp && rnd_n(3) == 0))) at += 1.2f, queue(i, L_SUS, w, g.p[w].room, at);
  }
  /* Meetings include a few purposeful questions, scaled by difficulty. */
  if (g.opt.difficulty >= 1) {
    int asked = 0;
    int max_asked = g.opt.difficulty >= 3 ? 4 : g.opt.difficulty == 2 ? 3 : 2;
    for (int k = 0; k < n && asked < max_asked; k++) {
      int i = order[k];
      if (!g.p[i].alive || g.p[i].imp) continue;
      Bot *B = &g.p[i].bot;
      int score, target = top_suspect(i, &score);
      if (target < 0 || score < 18) {
        target = -1; float freshest = -1.0f;
        for (int j = 0; j < g.nplayers; j++) if (j != i && g.p[j].alive && !g.p[j].imp && B->seen_t[j] > freshest) {
          freshest = B->seen_t[j]; target = j;
        }
        if (target < 0) for (int j = 0; j < g.nplayers; j++) if (j != i && g.p[j].alive) { target = j; break; }
      }
      if (target < 0 || (asked > 0 && rnd_n(B->personality == 0 ? 2 : (g.opt.difficulty >= 3 ? 3 : g.opt.difficulty == 2 ? 4 : 6)) != 0)) continue;
      at += 1.0f + rnd_f() * 1.2f;
      /* Ask first. The confirmation question is deliberately NOT scheduled here:
         it will be created only after the target has actually answered, using
         the room stated in that answer rather than this bot's guess. */
      queue_reply(i, L_ASK_WHERE, target, 0, 2.8f + asked * 3.2f);
      asked++;
    }
  }
}

static bool is_accusation_line(int kind) {
  return kind == L_SAW_KILL || kind == L_SAW_VENT || kind == L_SUS ||
         kind == L_NEAR_BODY || kind == L_SAW_WITH || kind == L_PLAYER_SUS ||
         kind == L_PLAYER_VENT || kind == L_PLAYER_KILL ||
         kind == L_PLAYER_NOT_TRUST || kind == L_PLAYER_LYING;
}

/* Impostors coordinate socially, but only one teammate reacts to avoid a
   conspicuous chorus. They may defend an exposed ally or reinforce a useful
   accusation against a crewmate. */
static void impostor_meeting_reaction(int speaker, int kind, int target) {
  if (!is_accusation_line(kind) || target < 0 || target >= g.nplayers ||
      !g.p[target].alive) return;
  int partner = -1;
  for (int j = 0; j < g.nplayers; j++) {
    if (j == speaker || !is_bot(j) || !g.p[j].alive || !g.p[j].imp) continue;
    if (g.p[target].imp) { partner = j; break; }
    if (partner < 0 && rnd_n(3) == 0) partner = j;
  }
  if (partner < 0) return;
  if (g.p[target].imp) {
    if (rnd_n(100) < 62)
      queue_reply(partner, L_PLAYER_DISAGREE, speaker, 0,
                  g.meet_t + 1.0f + rnd_f() * 1.6f);
  } else if (g.p[speaker].imp && rnd_n(100) < 48) {
    queue_reply(partner, L_PLAYER_AGREE, speaker, 0,
                g.meet_t + 1.1f + rnd_f() * 1.8f);
  }
}

/* Pick at most one useful response to a statement. The choice is based on
   each listener's own suspicion, trust in the speaker and recent observations,
   rather than broadcasting a canned reply from every bot. */
static void conversation_reaction(int speaker, int kind, int a, int b) {
  /* A request for information should elicit something useful when a bot has
     a recent observation, rather than being silently ignored. */
  if (kind == L_PLAYER_NEED_INFO) {
    int witness = -1, subject = -1; float freshest = 100000.0f;
    for (int i = 0; i < g.nplayers; i++) {
      if (i == speaker || !is_bot(i) || !g.p[i].alive) continue;
      Bot *W = &g.p[i].bot;
      for (int j = 0; j < g.nplayers; j++) {
        if (j == i || !g.p[j].alive || W->seen_t[j] <= 0 || W->seen_room[j] >= N_ROOMS) continue;
        float age = g.t - W->seen_t[j];
        if (age >= 0 && age < 24 && age < freshest) {
          witness = i; subject = j; freshest = age;
        }
      }
    }
    if (witness >= 0)
      queue_reply(witness, L_PLAYER_SEEN_IN_ROOM, subject,
                  g.p[witness].bot.seen_room[subject], g.meet_t + 0.9f + rnd_f() * 1.3f);
    else {
      int curious = -1;
      for (int i = 0; i < g.nplayers; i++)
        if (i != speaker && is_bot(i) && g.p[i].alive &&
            (g.p[i].bot.personality == 0 || g.p[i].bot.personality == 2)) { curious = i; break; }
      if (curious >= 0) queue_reply(curious, L_WHO, 0, 0, g.meet_t + 1.0f + rnd_f());
    }
    return;
  }

  /* Bots react to the player's stated opinion, but their own evidence and
     personality decide whether they agree or push back. */
  if ((kind == L_PLAYER_AGREE || kind == L_PLAYER_DISAGREE || kind == L_PLAYER_TRUST ||
       kind == L_PLAYER_NOT_TRUST || kind == L_PLAYER_SAFE || kind == L_PLAYER_ALIBI ||
       kind == L_PLAYER_VOTE) && a >= 0 && a < g.nplayers && g.p[a].alive) {
    int chosen = -1, best = -1000;
    for (int i = 0; i < g.nplayers; i++) {
      if (i == speaker || !is_bot(i) || !g.p[i].alive) continue;
      Bot *B = &g.p[i].bot;
      int score = B->sus[a] - B->relation[a] / 3;
      if (B->personality == 0) score += 5;
      if (B->personality == 2) score -= 5;
      if (score > best) best = score, chosen = i;
    }
    if (chosen >= 0 && rnd_n(100) < 58) {
      int reply = (best > 18) ? L_PLAYER_DISAGREE : L_PLAYER_AGREE;
      queue_reply(chosen, reply, a, 0, g.meet_t + 0.9f + rnd_f() * 1.5f);
    }
    return;
  }

  if (is_accusation_line(kind) && a < g.nplayers && g.p[a].alive) {
    int chosen = -1, best = -1000;
    for (int i = 0; i < g.nplayers; i++) {
      if (i == speaker || i == a || !is_bot(i) || !g.p[i].alive) continue;
      Bot *B = &g.p[i].bot;
      int score = B->sus[a] + B->credibility[speaker] / 6;
      if (B->personality == 0) score += 5;       /* detective reacts to claims */
      else if (B->personality == 2) score -= 5;  /* skeptic needs stronger proof */
      else if (B->personality == 3) score += 8;  /* follower follows the discussion */
      if (score > best) best = score, chosen = i;
    }
    if (chosen >= 0) {
      int reply = -1;
      int chance = g.opt.difficulty >= 3 ? 78 : g.opt.difficulty == 2 ? 68 : g.opt.difficulty == 1 ? 52 : 35;
      if (best >= 24 && rnd_n(100) < chance) reply = L_PLAYER_AGREE;
      else if (best <= -12 && rnd_n(100) < chance) reply = L_PLAYER_DISAGREE;
      else if ((g.p[chosen].bot.personality == 0 || g.p[chosen].bot.personality == 2) &&
               rnd_n(100) < 24) reply = L_PLAYER_NEED_INFO;
      if (reply >= 0)
        queue_reply(chosen, reply, reply == L_PLAYER_NEED_INFO ? 0 : speaker, 0,
                    g.meet_t + 0.9f + rnd_f() * 1.8f);
    }
    return;
  }

  /* A witness can corroborate or challenge a location claim only if their
     own recent sighting is fresh enough. */
  int subject = -1, room = -1;
  if (kind == L_WAS_IN || kind == L_PLAYER_IN_ROOM_ONLY) {
    subject = speaker; room = a;
  } else if (kind == L_PLAYER_SEEN_IN_ROOM || kind == L_PLAYER_LAST_IN_ROOM ||
             kind == L_PLAYER_SEEN_ROOM || kind == L_PLAYER_IN_ROOM ||
             kind == L_PLAYER_CONFIRM) {
    subject = a; room = b;
  }
  if (subject < 0 || subject >= g.nplayers || room < 0 || room >= N_ROOMS) return;
  int witness = -1; float freshest = 100000.0f; bool agrees = false;
  for (int i = 0; i < g.nplayers; i++) {
    if (i == speaker || !is_bot(i) || !g.p[i].alive) continue;
    Bot *W = &g.p[i].bot;
    float age = g.t - W->seen_t[subject];
    if (age < 0 || age >= 35 || W->seen_room[subject] >= N_ROOMS || age >= freshest) continue;
    witness = i; freshest = age; agrees = W->seen_room[subject] == room;
  }
  if (witness >= 0 && rnd_n(100) < 72) {
    if (agrees) queue_reply(witness, L_CONFIRM, subject, room,
                            g.meet_t + 0.8f + rnd_f() * 1.2f);
    else queue_reply(witness, L_PLAYER_LYING, speaker, 0,
                     g.meet_t + 0.8f + rnd_f() * 1.2f);
  }
}

void bot_meeting_tick(void) {
  while (qnext < nqueue && g.meet_t >= queue_at[qnext]) {
    int who = queue_who[qnext], k = queue_kind[qnext], a = queue_a[qnext], b = queue_b[qnext];
    qnext++;
    if (!g.p[who].alive) continue;
    say(who, k, a, b);
    impostor_meeting_reaction(who, k, a);
    if (is_accusation_line(k) && a < g.nplayers && a != who &&
        is_bot(a) && g.p[a].alive &&
        rnd_n(100) < (g.opt.difficulty >= 3 ? 96 : g.opt.difficulty == 2 ? 92 : g.opt.difficulty == 1 ? 82 : 65))
      queue_reply(a, L_NOT_ME, 0, 0, g.meet_t + 0.8f + rnd_f() * 1.2f);
    conversation_reaction(who, k, a, b);
    for (int i = 0; i < g.nplayers; i++) if (i != who && is_bot(i) && g.p[i].alive) {
      Bot *M = &g.p[i].bot;
      if (M->heard_claims[who] < 255) M->heard_claims[who]++;
      M->last_claim_kind[who] = (uint8_t)k;
      M->last_claim_target[who] = (uint8_t)a;
      M->last_claim_room[who] = (uint8_t)b;
    }

    /* Cross-check location claims against each listener's own recent observations.
       Every difficulty can notice a direct contradiction; harder bots weigh it more. */
    {
      int claim_room = -1, claim_player = -1;
      if (k == L_WAS_IN || k == L_ANSWER_WHERE || k == L_PLAYER_IN_ROOM_ONLY) claim_room = a;
      else if (k == L_WITH || k == L_PLAYER_IN_ROOM || k == L_PLAYER_SEEN_ROOM ||
               k == L_PLAYER_SEEN_IN_ROOM || k == L_PLAYER_LAST_IN_ROOM ||
               k == L_PLAYER_CONFIRM || k == L_PLAYER_LEFT_ROOM) {
        claim_room = b;
        claim_player = (k == L_PLAYER_SEEN_ROOM || k == L_PLAYER_SEEN_IN_ROOM ||
                        k == L_PLAYER_LAST_IN_ROOM || k == L_PLAYER_CONFIRM ||
                        k == L_PLAYER_LEFT_ROOM) ? a : who;
      }
      if (claim_room >= 0 && claim_room < N_ROOMS) {
        for (int i = 0; i < g.nplayers; i++) {
          if (i == who || !is_bot(i) || !g.p[i].alive || g.p[i].imp) continue;
          Bot *W = &g.p[i].bot;
          int subject = claim_player >= 0 ? claim_player : who;
          float age = g.t - W->seen_t[subject];
          if (age >= 0 && age < 35 && W->seen_room[subject] < N_ROOMS) {
            if (W->seen_room[subject] != claim_room) {
              int penalty = g.opt.difficulty == 0 ? 4 : g.opt.difficulty == 1 ? 7 : 10;
              int c = W->credibility[who] - penalty;
              W->credibility[who] = (int8_t)(c < -100 ? -100 : c);
              if (g.p[who].imp && W->false_claims[who] < 255) W->false_claims[who]++;
              suspect(W, who, penalty + 2);
            } else if (W->credibility[who] < 95) W->credibility[who] += 2;
          }
        }
      }
    }

    /* A direct question gets a factual answer from the addressee's own memory. */
    if (k == L_ASK_WHERE && a < g.nplayers && g.p[a].alive && is_bot(a)) {
      int room = g.p[a].room;
      queue_reply(a, L_ANSWER_WHERE, room, who, g.meet_t + 0.7f + rnd_f() * 0.7f);
    }
    /* A bot may ask for witnesses only AFTER hearing the answer. The room
       comes from the answer itself (a), never from the questioner's memory. */
    if (k == L_ANSWER_WHERE && b < g.nplayers &&
        b != g.me && is_bot(b) && g.p[b].alive && a < N_ROOMS) {
      queue_reply(b, L_ASK_CONFIRM, who, a, g.meet_t + 0.8f + rnd_f() * 0.5f);
    }
    if (k == L_ASK_CONFIRM && a < g.nplayers) {
      int best = -1; float freshest = 100000.0f;
      for (int j = 0; j < g.nplayers; j++) {
        if (j == who || j == a || !is_bot(j) || !g.p[j].alive) continue;
        Bot *W = &g.p[j].bot;
        float age = g.t - W->seen_t[a];
        if (age >= 0 && age < 35 && W->seen_room[a] == b && age < freshest) best = j, freshest = age;
      }
      if (best >= 0) queue_reply(best, L_CONFIRM, a, b, g.meet_t + 0.8f + rnd_f());
      else if (g.p[who].bot.personality == 0) queue_reply(who, L_NO_CONFIRM, a, b, g.meet_t + 1.0f);
    }

    /* Every listener compares answers with its own observations. Reported claims
       remain claims until independently corroborated. */
    if (k == L_ANSWER_WHERE && b < g.nplayers) {
      int challenger = -1;
      for (int i = 0; i < g.nplayers; i++) if (i != who && is_bot(i) && g.p[i].alive && !g.p[i].imp) {
        Bot *B = &g.p[i].bot;
        if (g.t - B->seen_t[who] < 35 && B->seen_room[who] < N_ROOMS && B->seen_room[who] != a) {
          int v = B->credibility[who] - 12; B->credibility[who] = (int8_t)(v < -100 ? -100 : v);
          if (B->relation[who] > -60) B->relation[who] -= 3;
          suspect(B, who, 18);
          if (challenger < 0 && (B->personality == 0 || B->personality == 4)) challenger = i;
        }
      }
      if (challenger >= 0) queue_reply(challenger, L_PLAYER_LYING, who, 0, g.meet_t + 0.7f + rnd_f() * 0.4f);
    } else if (k == L_CONFIRM && a < g.nplayers) {
      for (int i = 0; i < g.nplayers; i++) if (is_bot(i) && g.p[i].alive && !g.p[i].imp) {
        Bot *B = &g.p[i].bot;
        if (B->credibility[who] < 95) B->credibility[who] += 5;
        if (B->relation[who] < 60) B->relation[who] += 2;
        if (B->sus[a] > -75) suspect(B, a, -8);
      }
    }

    /* Ordinary accusations are weighted by the speaker's earned credibility. */
    if (k == L_SAW_KILL || k == L_SAW_VENT || k == L_SUS || k == L_NEAR_BODY || k == L_SAW_WITH) {
      for (int i = 0; i < g.nplayers; i++) {
        if (i == who || !is_bot(i) || !g.p[i].alive || g.p[i].imp) continue;
        Bot *B = &g.p[i].bot;
        if (i == a) { suspect(B, who, 25); continue; }
        int trust = B->credibility[who] < 20 ? 0 : B->credibility[who] > 75 ? 2 : 1;
        int w = (k == L_SAW_KILL ? 45 : k == L_SAW_VENT ? 40 : k == L_NEAR_BODY ? 7 : k == L_SAW_WITH ? 5 : 12) * trust;
        w = w * (g.opt.difficulty == 0 ? 1 : 2) / 2;
        suspect(B, a, w);
      }
    }
    if (k == L_SCANNED)
      for (int i = 0; i < g.nplayers; i++)
        if (is_bot(i) && !g.p[i].imp && g.p[i].bot.sus[who] < 30) suspect(&g.p[i].bot, a, -40);
  }
}

/* the bots' votes (each at its own moment in the voting time) */
void bot_votes(void) {
  for (int i = 0; i < g.nplayers; i++) {
    if (!is_bot(i) || !g.p[i].alive || g.votes[i] != NONE) continue;
    if (g.meet_stage != 1) continue;
    /* decide after a few seconds of voting, or soon after everyone spoke */
    float when = 2.0f + (float)((i * 37 + g.nlines * 11) % 9);
    if (g.meet_t < when) continue;
    Bot *B = &g.p[i].bot;
    int s, w = top_suspect(i, &s);
    if (g.p[i].imp) {
      int counts[MAXP + 1] = {0};
      for (int j = 0; j < g.nplayers; j++)
        if (g.votes[j] != NONE) counts[g.votes[j]]++;

      /* A teammate can be sacrificed when the crew is already converging on
         them; otherwise impostors keep pressure on a crewmate. */
      int exposed_ally = -1, ally_pressure = 0;
      for (int j = 0; j < g.nplayers; j++) {
        if (j == i || !g.p[j].alive || !g.p[j].imp) continue;
        int pressure = counts[j];
        for (int k = 0; k < g.nlines; k++)
          if (is_accusation_line(g.lines[k].kind) && g.lines[k].a == j)
            pressure += 1;
        if (pressure > ally_pressure) ally_pressure = pressure, exposed_ally = j;
      }

      int best_crew = -1, best_count = 0;
      for (int j = 0; j < g.nplayers; j++)
        if (g.p[j].alive && !g.p[j].imp && counts[j] > best_count)
          best_count = counts[j], best_crew = j;

      bool bus_ally = exposed_ally >= 0 &&
          ((ally_pressure >= 4 && rnd_n(100) < 72) ||
           (ally_pressure >= 2 && rnd_n(100) < 38));
      if (bus_ally) {
        g.votes[i] = (uint8_t)exposed_ally;
      } else if (best_crew >= 0) {
        g.votes[i] = (uint8_t)best_crew;
      } else if (w >= 0 && s > 8) {
        g.votes[i] = (uint8_t)w;
      } else {
        g.votes[i] = SKIP;
      }
    } else {
      /* sure enough: that one; half sure: with the crowd if it's the same one */
      int counts[MAXP + 1] = {0};
      for (int j = 0; j < g.nplayers; j++)
        if (g.votes[j] != NONE && g.votes[j] != SKIP) counts[g.votes[j]]++;
      bool crowd = w >= 0 && counts[w] >= (g.opt.difficulty >= 3 ? 4 : g.opt.difficulty == 2 ? 3 : 2) &&
                   s >= (g.opt.difficulty >= 3 ? 30 : g.opt.difficulty == 2 ? 25 : 15) && B->sus[w] > -30;
      /* Hard crewmates use distinct social styles: detectives weigh evidence,
         strategists balance evidence and consensus, skeptics demand corroboration,
         and followers are more responsive to a genuine voting trend. */
      int threshold = g.opt.difficulty >= 3 ? 34 : g.opt.difficulty == 2 ? 38 : 30;
      if (g.opt.difficulty >= 2) {
        if (B->personality == 0) threshold = 32;       /* detective */
        else if (B->personality == 1) threshold = 36;  /* strategist */
        else if (B->personality == 2) threshold = 48;  /* skeptic */
        else if (B->personality == 3) threshold = 29; /* follower */
        else if (B->personality == 4) threshold = 34; /* leader */
        else threshold = 52; /* discreet: demands strong evidence */
      }
      int social_score = w >= 0 ? s - B->relation[w] / 4 : s;
      bool personality_crowd = crowd || (g.opt.difficulty >= 2 && (B->personality == 3 || B->personality == 4) &&
          w >= 0 && counts[w] >= 2 && social_score >= 20 && B->sus[w] > -20);
      g.votes[i] = (uint8_t)(w >= 0 && (social_score >= threshold || personality_crowd) ? w : SKIP);
    }
  }
}

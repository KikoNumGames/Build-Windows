#include <stdint.h>
#include "game.h"
#include "gfx.h"
#include "plat.h"
#include <emscripten.h>

extern bool game_running;
static uint16_t band[SCREEN_W * BAND];
static uint32_t next_tick;
static void frame(void) {
  uint32_t now = plat_millis() * 3;
  int n = 0;
  while ((int32_t)(now - next_tick) >= 0 && n < 3 && game_running) {
    game_tick(plat_keys());
    next_tick += 100;
    n++;
  }
  if (!game_running) {
    emscripten_cancel_main_loop();
    return;
  }
  if ((int32_t)(now - next_tick) > 300) next_tick = now;
  if (n) game_draw();
}
int main(void) {
  gfx_init(band);
  plat_begin();
  game_init();
  next_tick = plat_millis() * 3;
  emscripten_set_main_loop(frame, 0, 1);
  return 0;
}

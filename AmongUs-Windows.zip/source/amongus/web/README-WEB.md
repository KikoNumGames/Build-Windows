AMONG US — VERSION NAVIGATEUR / WINDOWS

Cette version se joue directement dans un navigateur récent (Edge, Chrome, Firefox).
Aucun fichier .exe et aucune installation ne sont nécessaires.

LANCEMENT LOCAL
1. Décompressez l'archive.
2. Double-cliquez sur run-local.bat (Python doit être installé), ou ouvrez un terminal dans ce dossier.
3. En terminal, lancez : python -m http.server 8000
4. Ouvrez http://localhost:8000 dans votre navigateur.

Il faut utiliser un petit serveur local : ouvrir index.html directement en file://
ne permet généralement pas au navigateur de charger le fichier WebAssembly.

COMMANDES
ZQSD ou flèches : déplacement
E : utiliser / signaler / entrer ou sortir d'une bouche
Espace : tuer (Imposteur) / ouvrir le quick chat en réunion
Tab : carte / historique du chat
Échap : pause / fermer
Entrée : quick chat en réunion
F1 : mémoire des bots en réunion
P : pause/reprise de la discussion
Touches 0 à 9 : saisies numériques de certaines tâches
Home : sauvegarder et quitter

Les sauvegardes du navigateur sont conservées dans le stockage local du navigateur.

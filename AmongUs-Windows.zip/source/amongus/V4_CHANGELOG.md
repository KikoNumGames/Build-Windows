# Among Us NumWorks — V4 incremental changes

This archive is based on the supplied V3 source. Existing gameplay, maps, tasks, art, controls, difficulty choices and settings have been retained.

## Implemented in this V4 development pass

- Unified meeting chat storage at `MAX_LINES` (96), shared by bot and player messages. Oldest entries are discarded only when the bounded history is full.
- Added scrollable meeting chat history: Up moves to older messages and Down returns toward newer messages. The reading offset is retained when the panel is closed and reopened during the same meeting.
- Added meeting pause/resume on the calculator `+` key. While paused, the meeting clock and bot discussion queue stop; a visible pause label is shown.
- Added a separate confirmation step to Quick Chat after selecting the required player/location fields. Back returns to editing rather than sending.
- Added Expert+ (Hard) cross-checking of reported room/alibi claims against each bot's own recent observations. Contradictions affect credibility and suspicion but are not treated as omniscient proof.
- Reset pause and chat-scroll state at the beginning of each new meeting.
- Bumped the save schema version because the in-memory game state grew. Settings remain separately stored; incompatible old in-progress round saves are safely rejected by the existing loader.

## Build and test notes

- `epsilon_app.h` and `epsilon_files.h` are intentionally not bundled: the repository's build environment supplies them. `source/amongus/Makefile` continues to reference `../common/epsilon_app.h` and `../common/epsilon_files.h`.
- Host build: `make host` succeeded in this environment after supplying temporary empty dependency placeholders solely for the host Makefile dependency check; those placeholders are not included in this archive.
- Rules suite: `build/play --rules` reports 343 checks, 0 failed.
- Smoke run: a 2,000-frame crew game completed without a crash.
- Full `tests/check.py` run exceeded the available execution time, so the complete long-run/fuzz suite is not claimed as passed.
- The ARM/NumWorks `.nwa` build was not run here; this deliverable is the source ZIP, not an `.nwa`. Run the repository's GitHub Actions workflow to validate the target toolchain and external headers.

## V4.1 — meeting pause controls (requested focused change)

- Pausing a meeting with `+` now freezes only the meeting clock and bot activity; it no longer blocks the human player's controls.
- While paused, the human player can still use Quick Chat, open/read/scroll the discussion history, navigate the voting plates and cast a vote.
- Bot discussion and bot voting remain suspended until the meeting is resumed.
- Replaced the plain pause banner with a compact styled status capsule and pause icon.
- Host build succeeded and the rules suite passed (343 checks, 0 failed). The full `tests/check.py` run exceeded the available execution time. The ARM/NumWorks `.nwa` build was not run.

## V4.2 — corrected bot questioning and alibi confirmations

- Expert+ bots now ask `where were you?` first and wait for the target's actual `I was in ...` response.
- Only after that answer appears in chat can the questioner ask other players to confirm it.
- The room named in the confirmation question is taken from the answer (`L_ANSWER_WHERE`), not from the questioner's stale `seen_room` memory or a fallback guess.
- Player-initiated questions do not cause the answering bot to launch a confirmation request on the player's behalf.
- Validation: host build succeeded; rules suite reports 343 checks, 0 failed; `tests/check.py --fuzz 10` completed with all checks passed. The NumWorks ARM `.nwa` target was not rebuilt in this environment.

## V4.3 — VAR bot-memory inspector

- During meetings only, VAR opens a navigable bot list; Up/Down selects a bot, OK opens its memory, and Back returns/closes.
- The detail view shows only the selected bot's remembered player observations and beliefs: credibility/trust, suspicion, last observed room and age, time spent together, and number of heard claims.
- The inspector deliberately never displays actual roles, impostor flags, tasks, hidden identity data, or other role-revealing fields.
- The panel overlays the meeting screen without changing voting, chat, or bot memory. VAR closes it; the usual meeting controls remain available once closed.
- Validation for V4.3: host build succeeded; rules suite reports 343 checks, 0 failed; `tests/check.py build/play --fuzz 10` completed with all checks passed. The ARM/NumWorks `.nwa` target was not rebuilt because the ARM/Epsilon SDK toolchain is not available in this environment.


## V4.4 – mémoire sociale, meetings et identification des corps

- Les bots ont désormais six styles de personnalité : détective, stratège, sceptique, suiveur, leader et discret.
- Les soupçons faibles et anciens diminuent progressivement, tandis que les preuves directes fortes restent durables.
- Ajout d'une affinité sociale distincte de la crédibilité, alimentée par les observations répétées et les confirmations ; elle nuance les votes sans remplacer les preuves.
- Les bots détective/leader peuvent relever publiquement une contradiction de position lorsqu'une observation récente contredit une réponse.
- L'inspecteur VAR affiche aussi la personnalité, l'affinité et le nombre de fausses accusations mémorisées, sans afficher de rôle ni d'information secrète.
- Après un report de corps, l'écran annonce le pseudo du joueur mort et le nombre de corps présents depuis le dernier meeting.
- Le pseudo du propriétaire est dessiné sous chaque corps sur la carte du vaisseau.
- Deux quick chats supplémentaires : « [joueur] is dead » et « [joueur] is dead. Body found in [salle] ». Ils permettent de sélectionner un joueur mort.
- Les quick chats purement informatifs sur un décès ne sont pas interprétés comme une accusation par les bots.
- Les bots suiveurs et leaders peuvent rejoindre un joueur récemment observé, avec un point de rendez-vous légèrement décalé plutôt qu’un suivi parfaitement collé.
- Les sabotages des imposteurs tiennent davantage compte du contexte : lumière lors d’une approche risquée, communications si la barre de tâches est avancée, ou sabotage critique pour disperser un équipage nombreux.
- L’écran de fin affiche désormais le nombre de meetings, d’éjections et de joueurs morts de la partie.

Validation locale : compilation de l'exécutable hôte réussie, 343 tests de règles réussis et simulation complète d'une partie automatique terminée. La compilation ARM/NumWorks n'a pas été effectuée dans cet environnement.

## V4.1 – Evidence, impostor behavior and sabotage lockout

- Same-room sightings are no longer treated as meaningful evidence by themselves.
- A player seen with the victim is only raised as a weak lead when the sighting is very recent; the bot no longer turns an old sighting into a strong accusation.
- A player close to a body gives only a small suspicion increase, and a dense stack suppresses nearest-player attribution.
- Stack kills select among eligible nearby crew for bot impostors; nearby witnesses do not receive a false guaranteed killer identity.
- Impostors abandon protected targets quickly and stop pursuing a single target indefinitely, returning to a believable route before hunting again.
- Door closures and ship-wide sabotages are mutually exclusive; each room's existing door cooldown remains intact.
- False-claim counters now also account for disproved ordinary accusations when an innocent is ejected.

Validation: host build succeeds and the 343 rule checks pass. The full long-running simulation suite did not complete within the available execution window. Camera/Admin surveillance behavior and dedicated surveillance quick-chat phrases remain future work; they are not claimed as implemented in this build.


## V4.5 — dynamic meetings and social impostor behavior

- Reworked the meeting discussion queue so bots can react to accusations and recent location claims. At most a small number of relevant bots respond to each statement, selected using their own suspicion, credibility, personality and observations; the chat no longer relies only on a fixed opening sequence.
- Bots now answer player-initiated `Where were you?` questions on Easy, Normal and Hard, with a very high response rate. Witness confirmation requests are also available outside Hard.
- Accused bots can defend themselves; other bots can agree, disagree, request more information, corroborate a recent sighting or challenge a contradiction.
- Impostor teammates can selectively defend one another or reinforce an accusation against a crewmate. Their voting logic can also distance them from an exposed teammate by voting them out when the crew is already converging on that teammate.
- Contradicted impostor location claims now increase the listener's false-claim counter on every difficulty, not only Hard.
- Increased the default discussion time to 45 seconds and scaled the minimum discussion time with the number of living bots. Voting remains open for at least 20 seconds after everyone has voted, so the result does not disappear immediately.
- Rebuilt Quick Chat from one shared 39-entry list used by both selection and rendering. This fixes the two selectable-but-invisible phrases and exposes the full bot dialogue vocabulary (including equivalent player phrases) through a scrollable list.
- Kept the game-state structure unchanged; no save-schema bump is required.

Validation: host build succeeded; `build/play --rules` reports 343 checks, 0 failed; one automated crew game and one automated impostor game completed without a crash. The full long-running `tests/check.py` suite exceeded the available execution time. The ARM/NumWorks `.nwa` build was not run because the ARM toolchain is unavailable in this environment.

## V4.6 — player chat delivery, confirmations and impostor visibility

- Every player Quick Chat message is now delivered to the bot social-memory system, including phrases without a player placeholder. These messages update each bot's heard-claim history rather than being silently skipped.
- Player-initiated confirmation claims are checked against each bot's own recent sighting. A corroborated confirmation improves the bot's relation with the human speaker (+2) and credibility; a contradicted confirmation reduces both and increments the human impostor's false-claim counter when applicable.
- Bots can respond to requests for more information with a recent independently observed location, and react to the player's trust/agreement/vote statements according to their own suspicion and personality.
- The Quick Chat label for `I can confirm [player]` now displays the complete sent phrase, `I can confirm [player] was in [place]`. The confirmation screen also previews the exact message before sending, and the label buffer was enlarged to avoid truncating long phrases.
- When the human player is an impostor, teammate speaker names are shown in red in meeting chat. Lines that mention an impostor are also tinted red so their identity is easy to recognize.
- Impostors are less likely to visibly trail a distant target: target selection is limited to nearby candidates, hunts end sooner, and they break off when the target notices them, gets company or moves too far away.

Validation: host build succeeds; `build/play --rules` reports 343 checks, 0 failed; one automated crew game and one automated impostor game completed without a crash. The full `tests/check.py` suite exceeded the available execution window. The NumWorks ARM `.nwa` build was not run in this environment.


## V4.7 — surveillance, impostor tactics and Expert difficulty

- Crew bots sometimes visit the Admin table and Security cameras. Admin observations store anonymous room counts; camera observations update last-seen evidence and can detect a body in camera view for reporting. Comms sabotage disables camera information.
- Admin room counts do not reveal player identities. Bots only follow the busiest room when the observed count indicates a group.
- Bot impostors avoid camera-covered kill locations on Hard/Expert, select isolated targets more deliberately, use more credible fake-task durations, and vary sabotage/door timing.
- Added Expert as a fourth bot difficulty. It increases observation frequency, meeting questioning, and strategic pressure.
- Existing Easy, Normal and Hard levels remain available.
- Validation: host build succeeded; `./build/play --rules` passed (343 checks); `tests/check.py build/play --fuzz 40` completed with all checks passed. No ARM `.nwa` build was performed.


## Android synchronization — latest supplied NumWorks meeting-fix source

- Synchronized the shared game sources with the newly supplied NumWorks archive, including Expert difficulty, Admin/camera surveillance, updated impostor tactics and current meeting logic.
- Kept Android touch controls: dedicated Quick Chat button above the red action button; blue validates/sends; red backs out or cancels.
- Kept Bot Memory red-button Back behavior and the memory touch shortcut.
- Kept the two-page mobile How to Play screen without the Keys page and disabled calculator key legends on Android.
- Kept vertical-only player-page navigation, including discussion and post-vote processing; horizontal directions do not switch pages.
